<?php
class Ets_migrate
{
    public $category_separator;
    public $gallery_formatting;
    public $upsell_formatting;
    public $crosssell_formatting;
    public $total_rows;
    public $encoding;

    public function __construct()
    {
        $this->category_separator = ",";
        $this->gallery_formatting = 0;
        $this->upsell_formatting = 0;
        $this->crosssell_formatting = 0;
        $this->total_rows = 0;
        $this->encoding = "UTF-8";
    }
}