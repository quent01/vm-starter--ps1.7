<?php
/*
Plugin Name: Woo2Pres Connector
Description: Feed Woocommerce data, Wordpress posts and pages for Woocommerce (Prestashop) to Prestashop migration!
Author: ETS-Soft
*/

header('content-type: application/json; charset=utf-8');
header("access-control-allow-origin: *");

require_once(dirname(__FILE__) . '/export.php');
add_action('plugins_loaded', 'ets_oneclicktomigrate_init');
function ets_oneclicktomigrate_init()
{
    global $export;
    $export = new Ets_migrate();
    $GLOBALS['export'] = $export;
}

if (!defined('ETS_WP_LIMIT')) {
    $limited = get_option('ets_woo2presconnector_records');
    if ((int)$limited <= 100)
        $limited = 200;
    define('ETS_WP_LIMIT', $limited);
}
if (!defined('ETS_ONECLICKTOMIGRATE_PREFIX'))
    define('ETS_ONECLICKTOMIGRATE_PREFIX', 'woo2presconnector');
if (!defined('ETS_WP_CACHE_DIR'))
    define('ETS_WP_CACHE_DIR', dirname(__FILE__) . '/../cache/export/');
if (!defined('ETS_WP_DATA_XML') && isset($_GET['zip_file_name']) && ($zip_file_name = $_GET['zip_file_name']))
    define('ETS_WP_DATA_XML', ETS_WP_CACHE_DIR . $zip_file_name . '/');
//load script.
add_action('admin_enqueue_scripts', 'ets_oneclicktomigrate_load_script');
function ets_oneclicktomigrate_load_script()
{
    wp_enqueue_style('woo2presconnector_style', plugins_url('/assets/css/admin.css', dirname(__FILE__)));
    wp_enqueue_script('woo2presconnector_script', plugins_url('/assets/js/admin.js', dirname(__FILE__)));
    wp_localize_script('woo2presconnector_script', 'ajax_object', array('ajax_url' => admin_url('admin-ajax.php')));
}

//end.
//load ajax.
if (!function_exists('ets_oneclicktomigrate_ajax_export')) {
    function ets_oneclicktomigrate_ajax_export()
    {
        ob_clean();
        mfpd_settings_page();
    }

    add_action('wp_ajax_ets_ajax_export', 'ets_oneclicktomigrate_ajax_export');
    add_action('wp_ajax_nopriv_ets_ajax_export', 'ets_oneclicktomigrate_ajax_export');
}
//end ajax.
if (isset($_GET['get_file_zip']) && ($zip_file_name = $_GET['get_file_zip']) && @file_exists(($zipFile = ETS_WP_CACHE_DIR . $zip_file_name . '.zip'))) {
    ob_end_clean();
    header("Pragma: public");
    header("Expires: 0");
    header("Cache-Control: must-revalidate, post-check=0, pre-check=0");
    header("Cache-Control: private", false); // required for certain browsers
    header("Content-Transfer-Encoding: binary");
    header("Content-Length: " . filesize($zipFile));
    header("Content-type: application/zip");
    header("Content-Disposition: attachment; filename=$zip_file_name.zip");
    readfile($zipFile);
    exit();
}
//load menu and action export.
if ((isset($_GET['presconnector']) && $_GET['presconnector']) && isset($_GET['zip_file_name']) && ($zip_file_name = $_GET['zip_file_name'])) {
    ob_clean();
    add_action('wp', 'mfpd_settings_page');
}
add_action('admin_menu', 'ets_oneclicktomigrate_Add_My_Admin_Link');
function ets_oneclicktomigrate_Add_My_Admin_Link()
{
    add_menu_page('Woo2Pres Connector', 'Woo2Pres Connector', 'manage_options', 'export_data', 'mfpd_settings_page', plugins_url('images/woo2pres.png', dirname(__FILE__)), 50);
}

function mfpd_settings_page()
{
    @ini_set('display_errors', 'on');
    @ini_set('memory_limit', '-1');
    @ini_set('max_execution_time', '300');
    if (class_exists('WooCommerce'))
        require_once(dirname(__FILE__) . '/product.php');
    require_once(dirname(__FILE__) . '/category.php');
    require_once(dirname(__FILE__) . '/user.php');
    require_once(dirname(__FILE__) . '/formatting.php');
    //ajax percent.
    if (isset($_GET['ajaxPercentageExport']) && $_GET['ajaxPercentageExport'] && isset($_GET['presconnector']) && $_GET['presconnector']) {
        $exports = ets_get_cache_export('all');
        $table = !empty($exports['export_table']) ? $exports['export_table'] : '';
        $item_export = ets_get_cache_tracking();
        $percent = !empty($exports['export_percent']) ? $exports['export_percent'] : 1;
        if (isset($exports['total_zone']))
            $percent = 6;
        if (isset($exports['product']))
            $percent = 13;
        if (isset($exports['product_image']))
            $percent = 27;
        if (isset($exports['all_attribute']))
            $percent = 33;
        if (isset($exports['accessory']))
            $percent = 50;
        if (isset($exports['customer']))
            $percent = 66;
        if (isset($exports['order_history']))
            $percent = 77;
        if (isset($exports['total_post']))
            $percent = 81;
        if (isset($exports['order_message']))
            $percent = 93;
        if (isset($exports['total_page']))
            $percent = 99;
        if (isset($exports['wp_data_info']))
            $percent = 100;
        if (isset($exports['export_percent']) && $percent != $exports['export_percent'])
            ets_cache_export('export_percent', $percent);
        ets_return_json(array(
            'percent' => $percent,
            'table' => $table,
            'totalItemImported' => $item_export,
        ));
    }
    //ajax export.
    if (isset($_GET['zip_file_name']) && ($zip_file_name = $_GET['zip_file_name']) && ((isset($_POST['submitExport']) && $_POST['submitExport'] && isset($_REQUEST['ajax']) && $_REQUEST['ajax']) || (get_option('ets_woo2presconnector_enabled') && isset($_GET['presconnector']) && $_GET['presconnector'] && isset($_GET['pres2prestocken']) && $_GET['pres2prestocken'] && $_GET['pres2prestocken'] == get_option('ets_oneclicktomigrate_tocken')))) {
        $exportXmls = ETS_WP_CACHE_DIR . $zip_file_name . '/';
        if (!@is_dir($exportXmls))
            @mkdir($exportXmls, 0755);
        if (@file_exists($exportXmls) && !ets_get_cache_export('wp_data_info')) {
            if (class_exists('WooCommerce')) {
                if (!@file_exists($exportXmls . 'Zone.xml') && ($xml_output = ets_oneclicktomigrate_export_zones())) {
                    @file_put_contents($exportXmls . 'Zone.xml', ets_is_sanitizeXML($xml_output), LOCK_EX);
                    ets_return_json(array('export' => 'Zone.xml'));
                }
                if (!@file_exists($exportXmls . 'Currency.xml') && ($xml_output = ets_oneclicktomigrate_export_currencies())) {
                    @file_put_contents($exportXmls . 'Currency.xml', ets_is_sanitizeXML($xml_output), LOCK_EX);
                    ets_return_json(array('export' => 'Currency.xml'));
                }
                if (!@file_exists($exportXmls . 'Category.xml') && ($xml_output = ets_oneclicktomigrate_export_categories())) {
                    @file_put_contents($exportXmls . 'Category.xml', ets_is_sanitizeXML($xml_output), LOCK_EX);
                    ets_return_json(array('export' => 'Category.xml'));
                }
                if (!ets_get_cache_export('product')) {
                    $globs = glob($exportXmls . 'Product_*.xml');
                    $paged = is_array($globs) ? count($globs) + 1 : 1;
                    if (!@file_exists($exportXmls . 'Product_' . $paged . '.xml') && ($xml_output = ets_oneclicktomigrate_export_product(array('paged' => $paged, 'limit_volume' => ETS_WP_LIMIT)))) {
                        @file_put_contents($exportXmls . 'Product_' . $paged . '.xml', ets_is_sanitizeXML($xml_output), LOCK_EX);
                        ets_return_json(array('export' => 'Product_' . $paged . '.xml'));
                    }
                }
                if ((int)ets_get_cache_export('total_product')) {
                    if ((function_exists('wc_tax_enabled') && wc_tax_enabled()) || get_option('woocommerce_calc_taxes') === 'yes') {
                        if (!@file_exists($exportXmls . 'Tax.xml') && ($xml_output = ets_oneclicktomigrate_export_tax())) {
                            @file_put_contents($exportXmls . 'Tax.xml', ets_is_sanitizeXML($xml_output), LOCK_EX);
                            ets_return_json(array('export' => 'Tax.xml'));
                        }
                        if (!@file_exists($exportXmls . 'TaxRule.xml') && ($xml_output = ets_oneclicktomigrate_export_tax_rule())) {
                            @file_put_contents($exportXmls . 'TaxRule.xml', ets_is_sanitizeXML($xml_output), LOCK_EX);
                            ets_return_json(array('export' => 'TaxRule.xml'));
                        }
                        if (!@file_exists($exportXmls . 'TaxRulesGroup.xml') && ($xml_output = ets_oneclicktomigrate_export_tax_rule_group())) {
                            @file_put_contents($exportXmls . 'TaxRulesGroup.xml', ets_is_sanitizeXML($xml_output), LOCK_EX);
                            ets_return_json(array('export' => 'TaxRulesGroup.xml'));
                        }
                    }
                    if (!ets_get_cache_export('product_category')) {
                        $globs = glob($exportXmls . 'categoryproduct_*.xml');
                        $paged = is_array($globs) ? count($globs) + 1 : 1;
                        if (!file_exists($exportXmls . 'categoryproduct_' . $paged . '.xml') && ($xml_output = ets_oneclicktomigrate_export_product_category(array('paged' => $paged, 'limit_volume' => ETS_WP_LIMIT)))) {
                            @file_put_contents($exportXmls . 'categoryproduct_' . $paged . '.xml', ets_is_sanitizeXML($xml_output), LOCK_EX);
                            ets_return_json(array('export' => 'categoryproduct_' . $paged . '.xml'));
                        }
                    }
                    if (!ets_get_cache_export('product_image')) {
                        $globs = glob($exportXmls . 'Image_*.xml');
                        $paged = is_array($globs) ? count($globs) + 1 : 1;
                        if (!@file_exists($exportXmls . 'Image_' . $paged . '.xml') && ($xml_output = ets_oneclicktomigrate_export_product_image(array('paged' => $paged, 'limit_volume' => ETS_WP_LIMIT)))) {
                            @file_put_contents($exportXmls . 'Image_' . $paged . '.xml', ets_is_sanitizeXML($xml_output), LOCK_EX);
                            ets_return_json(array('export' => 'Image_' . $paged . '.xml'));
                        }
                    }
                    if (!@file_exists($exportXmls . 'Tag.xml') && ($xml_output = ets_oneclicktomigrate_export_tags())) {
                        @file_put_contents($exportXmls . 'Tag.xml', ets_is_sanitizeXML($xml_output), LOCK_EX);
                        ets_return_json(array('export' => 'Tag.xml'));
                    }
                    if ((int)ets_get_cache_export('total_tag') && !ets_get_cache_export('product_tag')) {
                        $globs = glob($exportXmls . 'producttag-*.xml');
                        $tag_paged = ($pageCached = (int)ets_get_cache_export('tag_paged')) ? ($pageCached + 1) : 1;
                        $ik = is_array($globs) ? (count($globs) + 1) : 1;
                        if (!@file_exists($exportXmls . 'producttag_' . $ik . '.xml') && ($xml_output = ets_oneclicktomigrate_export_product_tags(array('paged' => $tag_paged, 'limit_volume' => ETS_WP_LIMIT)))) {
                            @file_put_contents($exportXmls . 'producttag_' . $ik . '.xml', ets_is_sanitizeXML($xml_output), LOCK_EX);
                            ets_return_json(array('export' => 'producttag_' . $ik . '.xml'));
                        }
                    }


                    //get all attribute and feature.
                    if (!ets_get_cache_export('all_attribute')) {
                        $paged = ($pageCached = (int)ets_get_cache_export('product_paged')) ? ($pageCached + 1) : 1;
                        $caches = ets_oneclicktomigrate_export_get_attributes(array('paged' => $paged, 'limit_volume' => ETS_WP_LIMIT));
                        if (isset($caches['att']) && $caches['att'])
                            ets_cache_attributes($caches['att']);
                        if (isset($caches['fea']) && $caches['fea'])
                            ets_cache_features($caches['fea']);
                        ets_return_json(array('export' => 'getAttribute-' . $paged . '.xml'));
                    }
                    //end get all attribute and feature.
                    //export attribute.
                    if (!@file_exists($exportXmls . 'AttributeGroup.xml') && ($xml_output = ets_oneclicktomigrate_export_attribute_group())) {
                        @file_put_contents($exportXmls . 'AttributeGroup.xml', ets_is_sanitizeXML($xml_output), LOCK_EX);
                        ets_return_json(array('export' => 'AttributeGroup.xml'));
                    }
                    if (!@file_exists($exportXmls . 'Attribute.xml') && ($xml_output = ets_oneclicktomigrate_export_attribute())) {
                        @file_put_contents($exportXmls . 'Attribute.xml', ets_is_sanitizeXML($xml_output), LOCK_EX);
                        ets_return_json(array('export' => 'Attribute.xml'));
                    }
                    if (!ets_get_cache_export('combination')) {
                        $globs = glob($exportXmls . 'Combination_*.xml');
                        $paged = is_array($globs) ? count($globs) + 1 : 1;
                        if (!@file_exists($exportXmls . 'Combination_' . $paged . '.xml') && ($xml_output = ets_oneclicktomigrate_export_comibiation(array('paged' => $paged, 'limit_volume' => ETS_WP_LIMIT)))) {
                            @file_put_contents($exportXmls . 'Combination_' . $paged . '.xml', ets_is_sanitizeXML($xml_output), LOCK_EX);
                            ets_return_json(array('export' => 'Combination_' . $paged . '.xml'));
                        }
                    }
                    if (!ets_get_cache_export('attribute_combination')) {
                        $globs = glob($exportXmls . 'productattributecombination_*.xml');
                        $paged = is_array($globs) ? count($globs) + 1 : 1;
                        if (!@file_exists($exportXmls . 'productattributecombination_' . $paged . '.xml') && ($xml_output = ets_oneclicktomigrate_export_attribute_combination(array('paged' => $paged, 'limit_volume' => ETS_WP_LIMIT)))) {
                            @file_put_contents($exportXmls . 'productattributecombination_' . $paged . '.xml', ets_is_sanitizeXML($xml_output), LOCK_EX);
                            ets_return_json(array('export' => 'productattributecombination_' . $paged . '.xml'));
                        }
                    }
                    //end export attribute.
                    //export feature.
                    if (!@file_exists($exportXmls . 'Feature.xml') && ($xml_output = ets_oneclicktomigrate_export_feature())) {
                        @file_put_contents($exportXmls . 'Feature.xml', ets_is_sanitizeXML($xml_output), LOCK_EX);
                        ets_return_json(array('export' => 'Feature.xml'));
                    }
                    if (!@file_exists($exportXmls . 'FeatureValue.xml') && ($xml_output = ets_oneclicktomigrate_export_feature_value())) {
                        @file_put_contents($exportXmls . 'FeatureValue.xml', ets_is_sanitizeXML($xml_output), LOCK_EX);
                        ets_return_json(array('export' => 'FeatureValue.xml'));
                    }
                    if (!ets_get_cache_export('feature_product')) {
                        $globs = glob($exportXmls . 'featureproduct_*.xml');
                        $paged = is_array($globs) ? count($globs) + 1 : 1;
                        if (!@file_exists($exportXmls . 'featureproduct_' . $paged . '.xml') && ($xml_output = ets_oneclicktomigrate_export_feature_product(array('paged' => $paged, 'limit_volume' => ETS_WP_LIMIT)))) {
                            @file_put_contents($exportXmls . 'featureproduct_' . $paged . '.xml', ets_is_sanitizeXML($xml_output), LOCK_EX);
                            ets_return_json(array('export' => 'featureproduct_' . $paged . '.xml'));
                        }
                    }
                    //end export feature.

                    if (!ets_get_cache_export('specific_price')) {
                        $globs = glob($exportXmls . 'SpecificPrice_*.xml');
                        $specific_paged = ($pageCached = ets_get_cache_export('specific_paged')) ? (int)$pageCached + 1 : 1;
                        $ik = is_array($globs) ? (count($globs) + 1) : 1;
                        if (!@file_exists($exportXmls . 'SpecificPrice_' . $ik . '.xml') && ($xml_output = ets_oneclicktomigrate_export_specific_price(array('paged' => $specific_paged, 'limit_volume' => ETS_WP_LIMIT)))) {
                            @file_put_contents($exportXmls . 'SpecificPrice_' . $ik . '.xml', ets_is_sanitizeXML($xml_output), LOCK_EX);
                            ets_return_json(array('export' => 'SpecificPrice_' . $ik . '.xml'));
                        }
                    }
                    if (!ets_get_cache_export('accessory')) {
                        $globs = glob($exportXmls . 'accessory_*.xml');
                        $accessory_paged = ($pageCached = ets_get_cache_export('accessory_paged')) ? (int)$pageCached + 1 : 1;
                        $ik = is_array($globs) ? (count($globs) + 1) : 1;
                        if (!@file_exists($exportXmls . 'accessory_' . $ik . '.xml') && ($xml_output = ets_oneclicktomigrate_export_accessory_product(array('paged' => $accessory_paged, 'limit_volume' => ETS_WP_LIMIT)))) {
                            @file_put_contents($exportXmls . 'accessory_' . $ik . '.xml', ets_is_sanitizeXML($xml_output), LOCK_EX);
                            ets_return_json(array('export' => 'accessory_' . $ik . '.xml'));
                        }
                    }
                }
                if (!@file_exists($exportXmls . 'Carrier.xml') && ($xml_output = ets_oneclicktomigrate_export_carriers())) {
                    @file_put_contents($exportXmls . 'Carrier.xml', ets_is_sanitizeXML($xml_output), LOCK_EX);
                    ets_return_json(array('export' => 'Carrier.xml'));
                }
                if (ets_get_cache_export('total_carriers') && !@file_exists($exportXmls . 'carrierzone.xml') && ($xml_output = ets_oneclicktomigrate_export_carrier_zone())) {
                    @file_put_contents($exportXmls . 'carrierzone.xml', ets_is_sanitizeXML($xml_output), LOCK_EX);
                    ets_return_json(array('export' => 'carrierzone.xml'));
                }
                if (ets_get_cache_export('total_carriers') && !@file_exists($exportXmls . 'RangePrice.xml') && ($xml_output = ets_oneclicktomigrate_export_range_price())) {
                    @file_put_contents($exportXmls . 'RangePrice.xml', ets_is_sanitizeXML($xml_output), LOCK_EX);
                    ets_return_json(array('export' => 'RangePrice.xml'));
                }
                if (ets_get_cache_export('total_carriers') && !@file_exists($exportXmls . 'Delivery.xml') && ($xml_output = ets_oneclicktomigrate_export_deliveries())) {
                    @file_put_contents($exportXmls . 'Delivery.xml', ets_is_sanitizeXML($xml_output), LOCK_EX);
                    ets_return_json(array('export' => 'Delivery.xml'));
                }
                if (!($customerExported = (int)ets_get_cache_export('customer'))) {
                    $globs = glob($exportXmls . 'Customer_*.xml');
                    $customer_paged = ($pageCached = (int)ets_get_cache_export('customer_paged')) ? ($pageCached + 1) : 1;
                    $ik = is_array($globs) ? (count($globs) + 1) : 1;
                    if (!@file_exists($exportXmls . 'Customer_' . $ik . '.xml') && ($xml_output = ets_oneclicktomigrate_export_customer(array('paged' => $customer_paged, 'limit' => ETS_WP_LIMIT)))) {
                        @file_put_contents($exportXmls . 'Customer_' . $ik . '.xml', ets_is_sanitizeXML($xml_output), LOCK_EX);
                        ets_return_json(array('export' => 'Customer_' . $ik . '.xml'));
                    }
                }
                if (!@file_exists($exportXmls . 'Group.xml') && ($xml_output = ets_oneclicktomigrate_export_group())) {
                    @file_put_contents($exportXmls . 'Group.xml', ets_is_sanitizeXML($xml_output), LOCK_EX);
                    ets_return_json(array('export' => 'Group.xml'));
                }
                if ($customerExported && !ets_get_cache_export('address')) {
                    $globs = glob($exportXmls . 'Address_*.xml');
                    $address_paged = ($pageCached = (int)ets_get_cache_export('address_paged')) ? ($pageCached + 1) : 1;
                    $ik = is_array($globs) ? (count($globs) + 1) : 1;
                    if (!@file_exists($exportXmls . 'Address_' . $ik . '.xml') && ($xml_output = ets_oneclicktomigrate_export_address(array('paged' => $address_paged, 'limit' => ETS_WP_LIMIT)))) {
                        @file_put_contents($exportXmls . 'Address_' . $ik . '.xml', ets_is_sanitizeXML($xml_output), LOCK_EX);
                        ets_return_json(array('export' => 'Address_' . $ik . '.xml'));
                    }
                }
                if ($customerExported && (int)ets_get_cache_export('total_address')) {
                    if (!@file_exists($exportXmls . 'Country.xml') && ($xml_output = ets_oneclicktomigrate_export_countries())) {
                        @file_put_contents($exportXmls . 'Country.xml', ets_is_sanitizeXML($xml_output), LOCK_EX);
                        ets_return_json(array('export' => 'Country.xml'));
                    }
                    if (!@file_exists($exportXmls . 'State.xml') && ($xml_output = ets_oneclicktomigrate_export_states())) {
                        @file_put_contents($exportXmls . 'State.xml', ets_is_sanitizeXML($xml_output), LOCK_EX);
                        ets_return_json(array('export' => 'State.xml'));
                    }
                }
                if ($customerExported && !ets_get_cache_export('cart')) {
                    $globs = glob($exportXmls . 'Cart_*.xml');
                    $cart_paged = ($pageCached = (int)ets_get_cache_export('cart_paged')) ? ($pageCached + 1) : 1;
                    $ik = is_array($globs) ? (count($globs) + 1) : 1;
                    if (!@file_exists($exportXmls . 'Cart_' . $ik . '.xml') && ($xml_output = ets_oneclicktomigrate_export_carts(array('paged' => $cart_paged, 'limit' => ETS_WP_LIMIT)))) {
                        @file_put_contents($exportXmls . 'Cart_' . $ik . '.xml', ets_is_sanitizeXML($xml_output), LOCK_EX);
                        ets_return_json(array('export' => 'Cart_' . $ik . '.xml'));
                    }
                }
                if ($customerExported && !@file_exists($exportXmls . 'OrderState.xml') && ($xml_output = ets_oneclicktomigrate_export_order_status())) {
                    @file_put_contents($exportXmls . 'OrderState.xml', ets_is_sanitizeXML($xml_output), LOCK_EX);
                    ets_return_json(array('export' => 'OrderState.xml'));
                }
                if ($customerExported && !ets_get_cache_export('order')) {
                    $globs = glob($exportXmls . 'Order_*.xml');
                    $order_paged = ($pageCached = (int)ets_get_cache_export('order_paged')) ? ($pageCached + 1) : 1;
                    $ik = is_array($globs) ? (count($globs) + 1) : 1;
                    if (!@file_exists($exportXmls . 'Order_' . $ik . '.xml') && ($xml_output = ets_oneclicktomigrate_export_orders(array('paged' => $order_paged, 'limit' => ETS_WP_LIMIT)))) {
                        @file_put_contents($exportXmls . 'Order_' . $ik . '.xml', ets_is_sanitizeXML($xml_output), LOCK_EX);
                        ets_return_json(array('export' => 'Order_' . $ik . '.xml'));
                    }
                }
                if ($customerExported && !ets_get_cache_export('order_detail')) {
                    $globs = glob($exportXmls . 'OrderDetail_*.xml');
                    $od_paged = ($pageCached = (int)ets_get_cache_export('od_paged')) ? ($pageCached + 1) : 1;
                    $ik = is_array($globs) ? (count($globs) + 1) : 1;
                    if (!@file_exists($exportXmls . 'OrderDetail_' . $ik . '.xml') && ($xml_output = ets_oneclicktomigrate_export_order_detail(array('paged' => $od_paged, 'limit' => ETS_WP_LIMIT)))) {
                        @file_put_contents($exportXmls . 'OrderDetail_' . $ik . '.xml', ets_is_sanitizeXML($xml_output), LOCK_EX);
                        ets_return_json(array('export' => 'OrderDetail_' . $ik . '.xml'));
                    }
                }
                if ($customerExported && !ets_get_cache_export('order_history')) {
                    $globs = glob($exportXmls . 'OrderHistory_*.xml');
                    $oh_paged = ($pageCached = (int)ets_get_cache_export('oh_paged')) ? ($pageCached + 1) : 1;
                    $ik = is_array($globs) ? (count($globs) + 1) : 1;
                    if (!@file_exists($exportXmls . 'OrderHistory_' . $ik . '.xml') && ($xml_output = ets_oneclicktomigrate_export_order_history(array('paged' => $oh_paged, 'limit' => ETS_WP_LIMIT)))) {
                        @file_put_contents($exportXmls . 'OrderHistory_' . $ik . '.xml', ets_is_sanitizeXML($xml_output), LOCK_EX);
                        ets_return_json(array('export' => 'OrderHistory_' . $ik . '.xml'));
                    }
                }
                if ($customerExported && !ets_get_cache_export('order_message')) {
                    $globs = glob($exportXmls . 'Message_*.xml');
                    $om_paged = ($pageCached = (int)ets_get_cache_export('om_paged')) ? ($pageCached + 1) : 1;
                    $ik = is_array($globs) ? (count($globs) + 1) : 1;
                    if (!@file_exists($exportXmls . 'Message_' . $ik . '.xml') && ($xml_output = ets_oneclicktomigrate_export_order_message(array('paged' => $om_paged, 'limit' => ETS_WP_LIMIT)))) {
                        @file_put_contents($exportXmls . 'Message_' . $ik . '.xml', ets_is_sanitizeXML($xml_output), LOCK_EX);
                        ets_return_json(array('export' => 'Message_' . $ik . '.xml'));
                    }
                }
                if (!@file_exists($exportXmls . 'CartRule.xml') && ($xml_output = ets_oneclicktomigrate_export_cart_rule())) {
                    @file_put_contents($exportXmls . 'CartRule.xml', ets_is_sanitizeXML($xml_output), LOCK_EX);
                    ets_return_json(array('export' => 'CartRule.xml'));
                }
            }
            if (!@file_exists($exportXmls . 'CMS.xml') && ($xml_output = ets_oneclicktomigrate_export_posts())) {
                @file_put_contents($exportXmls . 'CMS.xml', ets_is_sanitizeXML($xml_output), LOCK_EX);
                ets_return_json(array('export' => 'CMS.xml'));
            }
            if ((int)ets_get_cache_export('total_post') && !@file_exists($exportXmls . 'CMSCategory.xml') && ($xml_output = ets_oneclicktomigrate_export_cms_category())) {
                @file_put_contents($exportXmls . 'CMSCategory.xml', ets_is_sanitizeXML($xml_output), LOCK_EX);
                ets_return_json(array('export' => 'CMSCategory.xml'));
            }
            if (!@file_exists($exportXmls . 'page_cms.xml') && ($xml_output = ets_oneclicktomigrate_export_pages())) {
                @file_put_contents($exportXmls . 'page_cms.xml', ets_is_sanitizeXML($xml_output), LOCK_EX);
                ets_return_json(array('export' => 'page_cms.xml'));
            }
            //36.
            if (!@file_exists($exportXmls . 'WPDataInfo.xml') && ($xml_output = ets_oneclicktomigrate_exportinfo())) {
                @file_put_contents($exportXmls . 'WPDataInfo.xml', ets_is_sanitizeXML($xml_output), LOCK_EX);
                ets_return_json(array('export' => 'WPDataInfo.xml'));
            }
        } elseif (!@file_exists($exportXmls)) {
            ets_return_json(array(
                'errors' => __('Export errors!', 'woo2presconnector'),
            ));
        }
        $zip = new ZipArchive();
        $errors = array();
        if ($zip->open(ETS_WP_CACHE_DIR . $zip_file_name . '.zip', ZipArchive::OVERWRITE | ZipArchive::CREATE) === true) {
            if (($files = glob($exportXmls . '*.xml'))) {
                foreach ($files as $file) {
                    if (!$zip->addFromString(basename($file), @file_get_contents($file))) {
                        $errors[] = __('Cannot create ', 'woo2presconnector') . basename($file);
                    }
                }
            }
        }
        if ($zip->close()) {
            if (ets_get_cache_export('wp_data_info'))
                ets_oneclicktomigrate_rmdir_cached($exportXmls);
        }
        $home_url = home_url('', (is_ssl() ? 'https' : 'http'));
        $linkZip = is_admin() ? admin_url('admin.php?page=export_data&get_file_zip=' . $zip_file_name, (is_ssl() ? 'https' : 'http')) : $home_url . (strpos($home_url, '?') != -1 ? '?' : '&') . 'get_file_zip=' . $zip_file_name;
        ets_return_json(array(
            'errors' => $errors ? $errors : false,
            'link_site_connector' => $linkZip,
        ));
    } elseif (isset($_GET['presconnector']) && $_GET['presconnector']) {
        ets_return_json(array(
            'errors' => __('Error access token.', 'woo2presconnector'),
        ));
    }
    //save setting.
    if (isset($_POST['save_woo2presconnector']) && $_POST['save_woo2presconnector']) {
        $errors = array();
        //token.
        if (!(isset($_POST['ets_oneclicktomigrate_tocken'])) || !$_POST['ets_oneclicktomigrate_tocken']) {
            $errors[] = __('Secure access token is required.', 'woo2presconnector');
        } else
            update_option('ets_oneclicktomigrate_tocken', $_POST['ets_oneclicktomigrate_tocken']);
        //record.
        if (!(isset($_POST['ets_woo2presconnector_records'])) || !$_POST['ets_woo2presconnector_records']) {
            $errors[] = __('Database records exported per ajax request is required.', 'woo2presconnector');
        } elseif (!preg_match('/^([1-4][0-9][0-9])?$|^500$/', $_POST['ets_woo2presconnector_records'])) {
            $errors[] = __('Database records exported per ajax request range [100-500].', 'woo2presconnector');
        } else
            update_option('ets_woo2presconnector_records', $_POST['ets_woo2presconnector_records']);
        //enabled.
        update_option('ets_woo2presconnector_enabled', $_POST['ets_woo2presconnector_enabled']);
        $ok_save = $errors ? false : true;
    }
    if (!(isset($_GET['presconnector']))) {
        include(dirname(__FILE__) . '/ets_oneclicktomigrate-admin-page.php');
    }
}

function ets_return_json($data)
{
    ob_end_clean();
    die(json_encode($data));
}

function ets_is_sanitizeXML($string)
{
    if (!empty($string)) {
        // remove EOT+NOREP+EOX|EOT+<char> sequence (FatturaPA)
        $string = preg_replace('/(\x{0004}(?:\x{201A}|\x{FFFD})(?:\x{0003}|\x{0004}).)/u', '', $string);
        $regex = '/(
                [\xC0-\xC1] # Invalid UTF-8 Bytes
                | [\xF5-\xFF] # Invalid UTF-8 Bytes
                | \xE0[\x80-\x9F] # Overlong encoding of prior code point
                | \xF0[\x80-\x8F] # Overlong encoding of prior code point
                | [\xC2-\xDF](?![\x80-\xBF]) # Invalid UTF-8 Sequence Start
                | [\xE0-\xEF](?![\x80-\xBF]{2}) # Invalid UTF-8 Sequence Start
                | [\xF0-\xF4](?![\x80-\xBF]{3}) # Invalid UTF-8 Sequence Start
                | (?<=[\x0-\x7F\xF5-\xFF])[\x80-\xBF] # Invalid UTF-8 Sequence Middle
                | (?<![\xC2-\xDF]|[\xE0-\xEF]|[\xE0-\xEF][\x80-\xBF]|[\xF0-\xF4]|[\xF0-\xF4][\x80-\xBF]|[\xF0-\xF4][\x80-\xBF]{2})[\x80-\xBF] # Overlong Sequence
                | (?<=[\xE0-\xEF])[\x80-\xBF](?![\x80-\xBF]) # Short 3 byte sequence
                | (?<=[\xF0-\xF4])[\x80-\xBF](?![\x80-\xBF]{2}) # Short 4 byte sequence
                | (?<=[\xF0-\xF4][\x80-\xBF])[\x80-\xBF](?![\x80-\xBF]) # Short 4 byte sequence (2)
            )/x';
        $string = preg_replace($regex, '', $string);
        $string = preg_replace('/<script\b[^>]*>(.*?)<\/script>/is', '', $string);
        $string = utf8_for_xml($string);
    }
    return html_entity_decode($string);
}

function utf8_for_xml($string)
{
    return preg_replace('/[^\x{0009}\x{000a}\x{000d}\x{0020}-\x{D7FF}\x{E000}-\x{FFFD}]+/u', '', $string);
}

function ets_oneclicktomigrate_rmdir_cached($dir)
{
    if (!is_dir($dir))
        return false;
    if (substr($dir, strlen($dir) - 1, 1) != '/')
        $dir .= '/';
    $files = glob($dir . '*', GLOB_MARK);
    foreach ($files as $file) {
        if (is_dir($file)) {
            ets_oneclicktomigrate_rmdir_cached($file);
        } else {
            unlink($file);
        }
    }
    rmdir($dir);
}

function ets_oneclicktomigrate_post_statuses($extra_status = array(), $override = false)
{
    $output = array(
        'publish',
        'pending',
        'draft',
        'future',
        'private',
        'trash'
    );
    if ($override) {
        $output = $extra_status;
    } else {
        if ($extra_status)
            $output = array_merge($output, $extra_status);
    }
    return $output;
}

function ets_oneclicktomigrate_get_option($option = null, $default = false, $allow_empty = false)
{

    $output = false;
    if ($option !== null) {
        $separator = '_';
        $output = get_option(ETS_ONECLICKTOMIGRATE_PREFIX . $separator . $option, $default);
        if ($allow_empty == false && $output != 0 && ($output == false || $output == ''))
            $output = $default;
    }
    return $output;
}

function ets_oneclicktomigrate_update_option($option = null, $value = null)
{
    $output = false;
    if ($option !== null && $value !== null) {
        $separator = '_';
        $output = update_option(ETS_ONECLICKTOMIGRATE_PREFIX . $separator . $option, $value);
    }
    return $output;
}

function ets_oneclicktomigrate_genSecure($size)
{
    $chars = md5(time());
    $code = '';
    for ($i = 1; $i <= $size; ++$i) {
        $char = substr($chars, rand(0, strlen($chars) - 1), 1);
        if ($char == 'e')
            $char = 'a';
        $code .= $char;
    }
    return $code;
}

function ets_oneclicktomigrate_export_get_total($exports)
{
    if (!$exports)
        return 0;
    $total = 0;
    foreach ($exports as $key => $export) {
        if (stripos($key, 'total_') == 0)
            $total += $export;
    }
    return $total;
}

function ets_oneclicktomigrate_exportinfo()
{
    ets_cache_export('export_table', 'data_info');
    global $wp_version;
    $xml_output = '<?xml version="1.0" encoding="UTF-8"?>' . "\n";
    $xml_output .= '<entity_profile>' . "\n";
    $xml_output .= '<domain>' . (isset($_SERVER['HTTP_X_FORWARDED_HOST']) ? $_SERVER['HTTP_X_FORWARDED_HOST'] : $_SERVER['HTTP_HOST']) . '</domain>' . "\n";
    $xml_output .= '<platform>Wordpress</platform>' . "\n";
    $xml_output .= '<link_site>' . get_site_url() . '</link_site>' . "\n";
    $xml_output .= '<version_wp>' . $wp_version . '</version_wp>' . "\n";
    $exports = ets_get_cache_export('all');
    $totalItemExport = (int)ets_oneclicktomigrate_export_get_total($exports);
    if (class_exists('WooCommerce')) {
        global $woocommerce;
        $xml_output .= '<version_woo>' . $woocommerce->version . '</version_woo>' . "\n";
        $xml_output .= '<id_currency_default>' . ets_oneclicktomigrate_get_id_currency(get_option('woocommerce_currency')) . '</id_currency_default>' . "\n";
        $xml_output .= '<countcurrency>' . (isset($exports['total_currency']) ? $exports['total_currency'] : 0) . '</countcurrency>' . "\n";
        $xml_output .= '<countcategory>' . (isset($exports['total_category']) ? $exports['total_category'] : 0) . '</countcategory>' . "\n";
        $xml_output .= '<countcustomer>' . (isset($exports['total_customer']) ? $exports['total_customer'] : 0) . '</countcustomer>' . "\n";
        $xml_output .= '<countcartrule>' . (isset($exports['total_cart_rule']) ? $exports['total_cart_rule'] : 0) . '</countcartrule>' . "\n";
        $xml_output .= '<countgroup>' . (isset($exports['total_group']) ? $exports['total_group'] : 0) . '</countgroup>' . "\n";
        $xml_output .= '<countaddress>' . (isset($exports['total_address']) ? $exports['total_address'] : 0) . '</countaddress>' . "\n";
        $xml_output .= '<countzone>' . (isset($exports['total_zone']) ? $exports['total_zone'] : 0) . '</countzone>' . "\n";
        $xml_output .= '<countrangeprice>' . (isset($exports['total_range_price']) ? $exports['total_range_price'] : 0) . '</countrangeprice>' . "\n";
        $xml_output .= '<countrangeweight>1</countrangeweight>' . "\n";
        $xml_output .= '<countdelivery>' . (isset($exports['total_delivery']) ? $exports['total_delivery'] : 0) . '</countdelivery>' . "\n";
        $xml_output .= '<countcarrier>' . (isset($exports['total_carrier']) ? $exports['total_carrier'] : 0) . '</countcarrier>' . "\n";
        $xml_output .= '<countcountry>' . (isset($exports['total_country']) ? $exports['total_country'] : 0) . '</countcountry>' . "\n";
        $xml_output .= '<countstate>' . (isset($exports['total_state']) ? $exports['total_state'] : 0) . '</countstate>' . "\n";
        $xml_output .= '<countproduct>' . (isset($exports['total_product']) ? $exports['total_product'] : 0) . '</countproduct>' . "\n";
        $xml_output .= '<countimage>' . (isset($exports['total_product_image']) ? $exports['total_product_image'] : 0) . '</countimage>' . "\n";
        $xml_output .= '<countcombination>' . (isset($exports['total_combinations']) ? $exports['total_combinations'] : 0) . '</countcombination>' . "\n";
        $xml_output .= '<countattributegroup>' . (isset($exports['total_attribute_group']) ? $exports['total_attribute_group'] : 0) . '</countattributegroup>' . "\n";
        $xml_output .= '<countattribute>' . (isset($exports['total_attribute']) ? $exports['total_attribute'] : 0) . '</countattribute>' . "\n";
        $xml_output .= '<countfeature>' . (isset($exports['total_feature']) ? $exports['total_feature'] : 0) . '</countfeature>' . "\n";
        $xml_output .= '<countfeaturevalue>' . (isset($exports['total_feature_value']) ? $exports['total_feature_value'] : 0) . '</countfeaturevalue>' . "\n";
        $xml_output .= '<countfeatureproduct>' . (isset($exports['total_feature_product']) ? $exports['total_feature_product'] : 0) . '</countfeatureproduct>' . "\n";
        $xml_output .= '<countspecificprice>' . (isset($exports['total_specific_price']) ? $exports['total_specific_price'] : 0) . '</countspecificprice>' . "\n";
        $xml_output .= '<counttaxrulesgroup>' . (isset($exports['total_tax_rule_group']) ? $exports['total_tax_rule_group'] : 0) . '</counttaxrulesgroup>' . "\n";
        $xml_output .= '<counttaxrule>' . (isset($exports['total_tax_rule']) ? $exports['total_tax_rule'] : 0) . '</counttaxrule>' . "\n";
        $xml_output .= '<counttag>' . (isset($exports['total_tag']) ? $exports['total_tag'] : 0) . '</counttag>' . "\n";
        $xml_output .= '<counttax>' . (isset($exports['total_tax']) ? $exports['total_tax'] : 0) . '</counttax>' . "\n";
        $xml_output .= '<countorder>' . (isset($exports['total_order']) ? $exports['total_order'] : 0) . '</countorder>' . "\n";
        $xml_output .= '<countorderstate>' . (isset($exports['total_order_status']) ? $exports['total_order_status'] : 0) . '</countorderstate>' . "\n";
        $xml_output .= '<countcart>' . (isset($exports['total_cart']) ? $exports['total_cart'] : 0) . '</countcart>' . "\n";
        $xml_output .= '<countorderdetail>' . (isset($exports['total_order_detail']) ? $exports['total_order_detail'] : 0) . '</countorderdetail>' . "\n";
        $xml_output .= '<countorderhistory>' . (isset($exports['total_order_history']) ? $exports['total_order_history'] : 0) . '</countorderhistory>' . "\n";
    }
    $xml_output .= '<countcms>' . (isset($exports['total_post']) ? $exports['total_post'] : 0) . '</countcms>' . "\n";
    $xml_output .= '<countpage>' . (isset($exports['total_page']) ? $exports['total_page'] : 0) . '</countpage>' . "\n";
    $xml_output .= '<countcmscategory>' . (isset($exports['total_cms_category']) ? $exports['total_cms_category'] : 0) . '</countcmscategory>' . "\n";
    if (class_exists('WooCommerce')) {
        $xml_output .= '<totalitem>' . ($totalItemExport + 3) . '</totalitem>' . "\n";
        $xml_output .= '<exporteddata>categories,customers,carriers,products,cms_cateogories,cms,page_cms,orders,cart_rules</exporteddata>' . "\n";
    } else {
        $xml_output .= '<totalitem>' . $totalItemExport . '</totalitem>' . "\n";
        $xml_output .= '<exporteddata>cms_cateogories,cms,page_cms</exporteddata>' . "\n";
    }
    $xml_output .= '</entity_profile>' . "\n";
    ets_cache_export('wp_data_info', 1);

    return $xml_output;
}

function ets_get_cache_tracking()
{
    $item_export = @file_get_contents(ETS_WP_DATA_XML . 'cache/tracking.cache');
    return (int)$item_export;
}

function ets_cache_tracking($item_export, &$time = 0)
{
    if (!$time || (time() - $time) >= 3) {
        if (!@is_dir(($cache = ETS_WP_DATA_XML . 'cache/')))
            @mkdir($cache, 0755);
        @file_put_contents($cache . 'tracking.cache', $item_export, LOCK_EX);
        $time = time();
    }
}

function ets_oneclicktomigrate_export_category($categories, &$xml_output, &$ik, &$time)
{
    $item_export = ets_get_cache_tracking();
    if ($categories) {
        foreach ($categories as $category) {
            $ik++;
            $xml_output .= '<category>' . "\n";
            $xml_output .= '<id_category><![CDATA[' . (int)$category->term_id . ']]></id_category>' . "\n";
            $xml_output .= '<id_parent><![CDATA[' . (int)$category->parent . ']]></id_parent>' . "\n";
            $xml_output .= '<woocommerce><![CDATA[1]]></woocommerce>' . "\n";
            $xml_output .= '<level_depth><![CDATA[]]></level_depth>' . "\n";
            $xml_output .= '<nleft><![CDATA[]]></nleft>' . "\n";
            $xml_output .= '<nright><![CDATA[]]></nright>' . "\n";
            $xml_output .= '<active><![CDATA[1]]></active>' . "\n";
            $xml_output .= '<link_image><![CDATA[' . (is_ssl() ? preg_replace('/(http:\/\/)/', 'https://', $category->image) : $category->image) . ']]></link_image>' . "\n";
            $xml_output .= '<datalanguage>' . "\n";
            $xml_output .= '<name><![CDATA[' . $category->name . ']]></name>' . "\n";
            $xml_output .= '<description><![CDATA[' . $category->description . ']]></description>' . "\n";
            $xml_output .= '<link_rewrite><![CDATA[' . $category->slug . ']]></link_rewrite>' . "\n";
            $xml_output .= '<meta_description><![CDATA[' . (get_post_meta($category->term_id, '_yoast_wpseo_metadesc', true) ? get_post_meta($category->term_id, '_yoast_wpseo_metadesc', true) : (get_post_meta($category->term_id, '_aioseop_description', true) ? get_post_meta($category->term_id, '_aioseop_description', true) : (get_post_meta($category->term_id, '_genesis_description', true) ? get_post_meta($category->term_id, '_genesis_description', true) : ''))) . ']]></meta_description>' . "\n";
            $xml_output .= '<meta_keywords><![CDATA[' . (get_post_meta($category->term_id, '_yoast_wpseo_focuskw', true) ? get_post_meta($category->term_id, '_yoast_wpseo_focuskw', true) : (get_post_meta($category->term_id, '_aioseop_keywords', true) ? get_post_meta($category->term_id, '_aioseop_keywords', true) : '')) . ']]></meta_keywords>' . "\n";
            $xml_output .= '<meta_title><![CDATA[' . (get_post_meta($category->term_id, '_yoast_wpseo_title', true) ? get_post_meta($category->term_id, '_yoast_wpseo_title', true) : (get_post_meta($category->term_id, '_aioseop_title', true) ? get_post_meta($category->term_id, '_aioseop_title', true) : (get_post_meta($category->term_id, '_genesis_title', true) ? get_post_meta($category->term_id, '_genesis_title', true) : ''))) . ']]></meta_title>' . "\n";
            $xml_output .= '</datalanguage>' . "\n";
            $xml_output .= '</category>' . "\n";
            ets_cache_tracking(++$item_export, $time);
            if (!empty($category->children))
                ets_oneclicktomigrate_export_category($category->children, $xml_output, $ik, $time);
        }
    }
    ets_cache_tracking($item_export);
    return $xml_output;
}

function ets_oneclicktomigrate_export_categories()
{
    ets_cache_export('export_table', 'category');
    $time = time();
    $categories = ets_oneclicktomigrate_get_product_categories();
    $xml_output = '<?xml version="1.0" encoding="UTF-8"?>' . "\n";
    $xml_output .= '<entity_profile>' . "\n";
    $ikCount = 0;
    if ($categories)
        ets_oneclicktomigrate_export_category($categories, $xml_output, $ikCount, $time);
    $xml_output .= '</entity_profile>' . "\n";
    ets_cache_export('total_category', $ikCount);
    if (!$ikCount)
        return false;
    return $xml_output;
}

function ets_cache_product($products, $paged)
{
    if (!$products || !$paged)
        return false;
    if (!@is_dir(($cache = ETS_WP_DATA_XML . 'cache/')))
        @mkdir($cache, 0755);
    if ($paged != -1)
        @file_put_contents($cache . 'product' . $paged . '.json', json_encode($products), LOCK_EX);
    unset($cache);
}

function ets_get_cache_product($paged = -1)
{
    if (@file_exists(($fileJson = ETS_WP_DATA_XML . 'cache/product' . ($paged != -1 ? $paged : '') . '.json')))
        return json_decode(@file_get_contents($fileJson));
    return array();
}

function ets_oneclicktomigrate_export_product($args = array())
{
    $paged = -1;
    if (isset($args['paged']))
        $paged = (int)$args['paged'];
    $products = ets_oneclicktomigrate_get_products($args);
    if (!$products) {
        ets_cache_export('product', 1);
        ets_return_json(array('export' => 'Product-end.xml'));
    }
    ets_cache_product($products, $paged);

    $item_export = ets_get_cache_tracking();
    ets_cache_export('export_table', 'product');
    $time = time();

    $xml_output = '<?xml version="1.0" encoding="UTF-8"?>' . "\n";
    $xml_output .= '<entity_profile>' . "\n";
    $count = ($ikCached = (int)ets_get_cache_export('total_product')) ? $ikCached : 0;
    foreach ($products as $product) {
        $count++;
        $categories = get_the_terms($product, 'product_cat');
        $wc_product = new WC_Product($product);
        $product = ets_oneclicktomigrate_get_product_data($product);
        $xml_output .= '<product>' . "\n";
        $xml_output .= '<id_product><![CDATA[' . (int)$product->product_id . ']]></id_product>' . "\n";
        $xml_output .= '<is_featured><![CDATA[' . (int)$wc_product->is_featured() . ']]></is_featured>' . "\n";
        $xml_output .= '<id_supplier><![CDATA[0]]></id_supplier>' . "\n";
        $xml_output .= '<id_manufacturer><![CDATA[1]]></id_manufacturer>' . "\n";
        $xml_output .= '<id_tax_rules_group><![CDATA[' . ($product->tax_status == 'Taxable' && wc_tax_enabled() ? ets_oneclicktomigrate_get_id_tax_rule_group($product->tax_class) : 0) . ']]></id_tax_rules_group>' . "\n";
        $xml_output .= '<id_category_default><![CDATA[' . (int)$categories[0]->term_id . ']]></id_category_default>' . "\n";
        $xml_output .= '<id_color_default><![CDATA[2]]></id_color_default>' . "\n";
        $xml_output .= '<on_sale><![CDATA[0]]></on_sale>' . "\n";
        $xml_output .= '<online_only><![CDATA[0]]></online_only>' . "\n";
        $xml_output .= '<ean13><![CDATA[0]]></ean13>' . "\n";
        $xml_output .= '<upc><![CDATA[]]></upc>' . "\n";
        $xml_output .= '<ecotax><![CDATA[0.000000]]></ecotax>' . "\n";
        $xml_output .= '<quantity><![CDATA[' . ($product->manage_stock == 'yes' ? (int)$product->quantity : 100) . ']]></quantity>' . "\n";
        $xml_output .= '<minimal_quantity><![CDATA[1]]></minimal_quantity>' . "\n";
        $xml_output .= '<price><![CDATA[' . (float)$product->price . ']]></price>' . "\n";
        $xml_output .= '<wholesale_price><![CDATA[' . (float)$product->regular_price . ']]></wholesale_price>' . "\n";
        $xml_output .= '<unity><![CDATA[]]></unity>' . "\n";
        $xml_output .= '<unit_price_ratio><![CDATA[0.000000]]></unit_price_ratio>' . "\n";
        $xml_output .= '<additional_shipping_cost><![CDATA[0.00]]></additional_shipping_cost>' . "\n";
        $xml_output .= '<reference><![CDATA[' . $product->sku . ']]></reference>' . "\n";
        $xml_output .= '<supplier_reference><![CDATA[]]></supplier_reference>' . "\n";
        $xml_output .= '<location><![CDATA[]]></location>' . "\n";
        $xml_output .= '<width><![CDATA[' . $product->width . ']]></width>' . "\n";
        $xml_output .= '<height><![CDATA[' . $product->height . ']]></height>' . "\n";
        $xml_output .= '<depth><![CDATA[0]]></depth>' . "\n";
        $xml_output .= '<weight><![CDATA[' . $product->weight . ']]></weight>' . "\n";
        $xml_output .= '<out_of_stock><![CDATA[2]]></out_of_stock>' . "\n";
        $xml_output .= '<quantity_discount><![CDATA[0]]></quantity_discount>' . "\n";
        $xml_output .= '<customizable><![CDATA[0]]></customizable>' . "\n";
        $xml_output .= '<uploadable_files><![CDATA[0]]></uploadable_files>' . "\n";
        $xml_output .= '<text_fields><![CDATA[0]]></text_fields>' . "\n";
        $xml_output .= '<active><![CDATA[' . ($product->product_status == 'Publish' ? '1' : '0') . ']]></active>' . "\n";
        $xml_output .= '<available_for_order><![CDATA[1]]></available_for_order>' . "\n";
        $xml_output .= '<condition><![CDATA[new]]></condition>' . "\n";
        $xml_output .= '<show_price><![CDATA[1]]></show_price>' . "\n";
        $xml_output .= '<indexed><![CDATA[1]]></indexed>' . "\n";
        $xml_output .= '<cache_is_pack><![CDATA[0]]></cache_is_pack>' . "\n";
        $xml_output .= '<cache_has_attachments><![CDATA[0]]></cache_has_attachments>' . "\n";
        $xml_output .= '<cache_default_attribute><![CDATA[0]]></cache_default_attribute>' . "\n";
        $xml_output .= '<date_add><![CDATA[' . $product->post_date_gmt . ']]></date_add>' . "\n";
        $xml_output .= '<date_upd><![CDATA[' . $product->post_modified_gmt . ']]></date_upd>' . "\n";
        $xml_output .= '<datalanguage>' . "\n";
        $xml_output .= '<description><![CDATA[' . $product->description . ']]></description>' . "\n";
        $xml_output .= '<description_short><![CDATA[' . $product->excerpt . ']]></description_short>' . "\n";
        $xml_output .= '<link_rewrite><![CDATA[' . $product->slug . ']]></link_rewrite>' . "\n";
        $xml_output .= '<meta_description><![CDATA[' . (get_post_meta($product->product_id, '_yoast_wpseo_metadesc', true) ? get_post_meta($product->product_id, '_yoast_wpseo_metadesc', true) : (get_post_meta($product->product_id, '_aioseop_description', true) ? get_post_meta($product->product_id, '_aioseop_description', true) : (get_post_meta($product->product_id, '_genesis_description', true) ? get_post_meta($product->product_id, '_genesis_description', true) : ''))) . ']]></meta_description>' . "\n";
        $xml_output .= '<meta_keywords><![CDATA[' . (get_post_meta($product->product_id, '_yoast_wpseo_focuskw', true) ? get_post_meta($product->product_id, '_yoast_wpseo_focuskw', true) : (get_post_meta($product->product_id, '_aioseop_keywords', true) ? get_post_meta($product->product_id, '_aioseop_keywords', true) : '')) . ']]></meta_keywords>' . "\n";
        $xml_output .= '<meta_title><![CDATA[' . (get_post_meta($product->product_id, '_yoast_wpseo_title', true) ? get_post_meta($product->product_id, '_yoast_wpseo_title', true) : (get_post_meta($product->product_id, '_aioseop_title', true) ? get_post_meta($product->product_id, '_aioseop_title', true) : (get_post_meta($product->product_id, '_genesis_title', true) ? get_post_meta($product->product_id, '_genesis_title', true) : ''))) . ']]></meta_title>' . "\n";
        $xml_output .= '<name><![CDATA[' . $product->name . ']]></name>' . "\n";
        $xml_output .= '<available_now><![CDATA[En stock]]></available_now>' . "\n";
        $xml_output .= '<available_later><![CDATA[]]></available_later>' . "\n";
        $xml_output .= '</datalanguage>' . "\n";
        $xml_output .= '</product>' . "\n";
        ets_cache_tracking(++$item_export, $time);
    }
    $xml_output .= '</entity_profile>' . "\n";
    ets_cache_tracking($item_export);
    ets_cache_export('total_product', $count);
    if ($count <= $ikCached)
        return false;
    return $xml_output;
}

function ets_oneclicktomigrate_export_product_category($args = array())
{
    $paged = -1;
    if (isset($args['paged']))
        $paged = (int)$args['paged'];
    $products = ets_get_cache_product($paged);
    if (!$products)
        $products = ets_oneclicktomigrate_get_products($args);
    if (!$products) {
        ets_cache_export('product_category', 1);
        ets_return_json(array('export' => 'categoryproduct-end.xml'));
    }
    $item_export = ets_get_cache_tracking();
    ets_cache_export('export_table', 'categoryproduct');
    $time = time();

    $xml_output = '<?xml version="1.0" encoding="UTF-8"?>' . "\n";
    $xml_output .= '<entity_profile>' . "\n";
    $total = ($ikCached = (int)ets_get_cache_export('total_product_category')) ? $ikCached : 0;
    foreach ($products as $product) {
        $categories = get_the_terms($product, 'product_cat');
        if ($categories) {
            $ik = 0;
            foreach ($categories as $category) {
                $xml_output .= '<category_product>' . "\n";
                $xml_output .= '<id_category><![CDATA[' . (int)$category->term_id . ']]></id_category>' . "\n";;
                $xml_output .= '<id_product><![CDATA[' . (int)$product . ']]></id_product>' . "\n";
                $xml_output .= '<position><![CDATA[' . (int)$ik . ']]></position>' . "\n";
                $xml_output .= '</category_product>' . "\n";
                $ik++;
                ets_cache_tracking(++$item_export, $time);
            }
            $total += $ik;
        }
    }
    $xml_output .= '</entity_profile>' . "\n";
    ets_cache_tracking($item_export);
    ets_cache_export('total_product_category', $total);
    if ($total <= $ikCached)
        return false;
    return $xml_output;
}

function ets_oneclicktomigrate_export_product_image($args = array())
{
    $paged = -1;
    if (isset($args['paged']))
        $paged = (int)$args['paged'];
    $products = ets_get_cache_product($paged);
    if (!$products)
        $products = ets_oneclicktomigrate_get_products($args);
    if (!$products) {
        ets_cache_export('product_image', 1);
        ets_return_json(array('export' => 'Image-end.xml'));
    }
    $item_export = ets_get_cache_tracking();
    ets_cache_export('export_table', 'product_image');
    $time = time();

    $xml_output = '<?xml version="1.0" encoding="UTF-8"?>' . "\n";
    $xml_output .= '<entity_profile>' . "\n";
    $auto_increment = ($ikCached = (int)ets_get_cache_export('total_product_image')) ? $ikCached : 0;
    foreach ($products as $product) {
        $p = ets_oneclicktomigrate_get_product_data($product);
        if ($p->image) {
            $auto_increment++;
            $xml_output .= '<image>' . "\n";
            $xml_output .= '<id_image><![CDATA[' . (int)$auto_increment . ']]></id_image>' . "\n";
            $xml_output .= '<id_product><![CDATA[' . (int)$p->product_id . ']]></id_product>' . "\n";
            $xml_output .= '<position><![CDATA[' . $auto_increment . ']]></position>' . "\n";
            $xml_output .= '<cover><![CDATA[1]]></cover>' . "\n";
            $xml_output .= '<link_image><![CDATA[' . (is_ssl() ? preg_replace('/(http:\/\/)/', 'https://', $p->image) : $p->image) . ']]></link_image>' . "\n";
            $xml_output .= '<datalanguage>' . "\n";
            $xml_output .= '<legend><![CDATA[' . $p->name . ']]></legend>' . "\n";
            $xml_output .= '</datalanguage>' . "\n";
            $xml_output .= '</image>' . "\n";
            ets_cache_tracking(++$item_export, $time);
        }
        if (isset($p->attachment_ids) && $p->attachment_ids) {
            foreach ($p->attachment_ids as $attachment_id) {
                $auto_increment++;
                $original_image_url = wp_get_attachment_url($attachment_id);
                $xml_output .= '<image>' . "\n";
                $xml_output .= '<id_image><![CDATA[' . (int)$auto_increment . ']]></id_image>' . "\n";
                $xml_output .= '<id_product><![CDATA[' . (int)$p->product_id . ']]></id_product>' . "\n";
                $xml_output .= '<position><![CDATA[' . (int)$auto_increment . ']]></position>' . "\n";
                $xml_output .= '<cover><![CDATA[0]]></cover>' . "\n";
                $xml_output .= '<link_image><![CDATA[' . (is_ssl() ? preg_replace('/(http:\/\/)/', 'https://', $original_image_url) : $original_image_url) . ']]></link_image>' . "\n";
                $xml_output .= '<datalanguage>' . "\n";
                $xml_output .= '<legend><![CDATA[' . $p->name . ']]></legend>' . "\n";
                $xml_output .= '</datalanguage>' . "\n";
                $xml_output .= '</image>' . "\n";
                ets_cache_tracking(++$item_export, $time);
            }
        }

    }
    $xml_output .= '</entity_profile>' . "\n";
    ets_cache_tracking($item_export);
    ets_cache_export('total_product_image', $auto_increment);
    return $xml_output;
}

function ets_oneclicktomigrate_export_group()
{
    $item_export = ets_get_cache_tracking();
    ets_cache_export('export_table', 'group');
    $time = time();
    $xml_output = '<?xml version="1.0" encoding="UTF-8"?>' . "\n";
    $xml_output .= '<entity_profile>' . "\n";
    $xml_output .= '<group>' . "\n";
    $xml_output .= '<id_group><![CDATA[1]]></id_group>' . "\n";
    $xml_output .= '<reduction><![CDATA[0.00]]></reduction>' . "\n";
    $xml_output .= '<price_display_method><![CDATA[1]]></price_display_method>' . "\n";
    $xml_output .= '<date_add><![CDATA[' . date('Y-m-d h:i:s', time()) . ']]></date_add>' . "\n";
    $xml_output .= '<date_upd><![CDATA[' . date('Y-m-d h:i:s', time()) . ']]></date_upd>' . "\n";
    $xml_output .= '<default_group><![CDATA[1]]></default_group>' . "\n";
    $xml_output .= '<datalanguage>' . "\n";
    $xml_output .= '<name><![CDATA[Default]]></name>' . "\n";
    $xml_output .= '</datalanguage>' . "\n";
    $xml_output .= '</group>' . "\n";
    $xml_output .= '</entity_profile>' . "\n";
    ets_cache_tracking(++$item_export);
    ets_cache_export('total_group', 1);
    return $xml_output;
}

//get all feature
function ets_cache_features($featureCached)
{
    if (!@is_dir(($cacheFile = ETS_WP_DATA_XML . 'cache/')))
        @mkdir($cacheFile, 0755);
    if ($featureCached) {
        @file_put_contents($cacheFile . 'features.json', json_encode($featureCached), LOCK_EX);
    }
    unset($cacheFile);
}

function ets_get_cache_features()
{
    if (@file_exists(($cacheFile = ETS_WP_DATA_XML . 'cache/features.json')))
        return json_decode(@file_get_contents($cacheFile));
    return array();
}

//end get all features.

//get all attribute.
function ets_cache_attributes($attributeCached)
{
    if (!@is_dir(($cacheFile = ETS_WP_DATA_XML . 'cache/')))
        @mkdir($cacheFile, 0755);
    if ($attributeCached) {
        @file_put_contents($cacheFile . 'attributes.json', json_encode($attributeCached), LOCK_EX);
    }
    unset($cacheFile);
}

function ets_get_cache_attributes()
{
    if (@file_exists(($cacheFile = ETS_WP_DATA_XML . 'cache/attributes.json')))
        return json_decode(@file_get_contents($cacheFile));
    return array();
}

//end get attribute.

//export attribute.
function ets_oneclicktomigrate_export_comibiation($args = array())
{
    $dataAttributes = ets_get_cache_attributes();
    if (!$dataAttributes) {
        $getAll = ets_oneclicktomigrate_export_get_attributes($args);
        if (isset($getAll['att']) && $getAll['att'])
            $dataAttributes = (array)$getAll['att'];
    }
    $paged = -1;
    if (isset($args['paged']))
        $paged = (int)$args['paged'];
    $products = ets_get_cache_product($paged);
    if (!$products)
        $products = ets_oneclicktomigrate_get_products($args);
    if (!$products) {
        ets_cache_export('combination', 1);
        ets_return_json(array('export' => 'product_attribute-end.xml'));
    }
    $item_export = ets_get_cache_tracking();
    ets_cache_export('export_table', 'product_attribute');
    $time = time();

    $xml_output = '<?xml version="1.0" encoding="UTF-8"?>' . "\n";
    $xml_output .= '<entity_profile>' . "\n";
    $ik = ($ikCached = (int)ets_get_cache_export('total_combinations')) ? $ikCached : 0;
    if ($products && $dataAttributes) {
        foreach ($products as $id_product) {
            $product_variation = new WC_Product_Variable($id_product);
            $combinations = $product_variation->get_available_variations();
            if ($combinations) {
                foreach ($combinations as $key => $combination) {
                    $xml_output .= "<product_attribute>" . "\n";;
                    $xml_output .= "<id_product_attribute><![CDATA[" . (int)$combination['variation_id'] . "]]></id_product_attribute>" . "\n";
                    $xml_output .= "<id_product><![CDATA[" . (int)$id_product . "]]></id_product>" . "\n";
                    $xml_output .= "<location><![CDATA[]]></location>" . "\n";
                    $xml_output .= "<ean13><![CDATA[]]></ean13>" . "\n";
                    $xml_output .= "<upc><![CDATA[]]></upc>" . "\n";
                    $xml_output .= "<quantity><![CDATA[100]]></quantity>" . "\n";
                    $xml_output .= "<reference><![CDATA[" . $combination['sku'] . "]]></reference>" . "\n";
                    $xml_output .= "<supplier_reference><![CDATA[]]></supplier_reference>" . "\n";
                    $xml_output .= "<wholesale_price><![CDATA[" . (float)$combination['display_price'] . "]]></wholesale_price>" . "\n";;
                    $xml_output .= "<price><![CDATA[0.000000]]></price>" . "\n";
                    $xml_output .= "<ecotax><![CDATA[0.000000]]></ecotax>" . "\n";;
                    $xml_output .= "<weight><![CDATA[" . (float)$combination['weight'] . "]]></weight>" . "\n";
                    $xml_output .= "<unit_price_impact><![CDATA[0.000000]]></unit_price_impact>" . "\n";
                    $xml_output .= "<minimal_quantity><![CDATA[" . (int)$combination['min_qty'] . "]]></minimal_quantity>" . "\n";
                    $xml_output .= "<default_on><![CDATA[" . ($key == 0 ? 1 : 0) . "]]></default_on>" . "\n";
                    $xml_output .= " <available_date><![CDATA[0000-00-00]]></available_date>" . "\n";
                    $xml_output .= '<datashop id_shop="1" id_product="' . (int)$id_product . '" wholesale_price="' . (float)$combination['display_price'] . '" price="0.000000" ecotax="0.000000" weight="' . (float)$combination['weight'] . '" unit_price_impact="0.000000" minimal_quantity="' . (int)$combination['min_qty'] . '"' . ($key == 0 ? ' default_on="1"' : '') . ' available_date="0000-00-00"></datashop>' . "\n";
                    $xml_output .= "</product_attribute>" . "\n";
                    ets_cache_tracking(++$item_export, $time);
                    $ik++;
                }
            }
        }
    }
    $xml_output .= '</entity_profile>' . "\n";
    ets_cache_tracking($item_export);
    ets_cache_export('total_combinations', $ik);
    if ($ik <= $ikCached)
        return false;
    return $xml_output;
}

function ets_oneclicktomigrate_export_attribute_combination($args = array())
{
    $dataAttributes = ets_get_cache_attributes();
    if (!$dataAttributes) {
        $getAll = ets_oneclicktomigrate_export_get_attributes($args);
        if (isset($getAll['att']) && $getAll['att'])
            $dataAttributes = (array)$getAll['att'];
    }
    $paged = -1;
    if (isset($args['paged']))
        $paged = (int)$args['paged'];
    $products = ets_get_cache_product($paged);
    if (!$products)
        $products = ets_oneclicktomigrate_get_products($args);
    if (!$products) {
        ets_cache_export('attribute_combination', 1);
        ets_return_json(array('export' => 'product_attribute-end.xml'));
    }
    $item_export = ets_get_cache_tracking();
    ets_cache_export('export_table', 'product_attribute');
    $time = time();

    $xml_output = '<?xml version="1.0" encoding="UTF-8"?>' . "\n";
    $xml_output .= '<entity_profile>' . "\n";
    $ik = ($ikCached = (int)ets_get_cache_export('total_attribute_combination')) ? $ikCached : 0;
    if ($products && $dataAttributes) {
        foreach ($products as $id_product) {
            $product_variation = new WC_Product_Variable($id_product);
            $combinations = $product_variation->get_available_variations();
            if ($combinations) {
                foreach ($combinations as $key => $combination) {
                    if ($combination['attributes']) {
                        $dataAttribute = array();
                        foreach ($combination['attributes'] as $key => $attribute) {
                            $key_value = str_replace('attribute_', '', $key);
                            ets_oneclicktomigrate_get_attributes($key_value, array($attribute), $dataAttribute);
                        }

                        if ($dataAttribute) {
                            foreach ($dataAttribute as $key => $productAttribute) {
                                if ($productAttribute) {
                                    foreach ($productAttribute as $attribute_value) {
                                        $id_attribute = ets_oneclicktomigrate_get_id_attribute($dataAttributes, $key, $attribute_value);
                                        if ($id_attribute) {
                                            $xml_output .= "<product_attribute_combination>" . "\n";;
                                            $xml_output .= "<id_attribute><![CDATA[" . (int)$id_attribute . "]]></id_attribute>" . "\n";
                                            $xml_output .= "<id_product_attribute><![CDATA[" . (int)$combination['variation_id'] . "]]></id_product_attribute>" . "\n";
                                            $xml_output .= "</product_attribute_combination>" . "\n";
                                            ets_cache_tracking(++$item_export, $time);
                                            $ik++;
                                        }

                                    }
                                }
                            }
                        }

                    }
                }
            }
        }
    }
    $xml_output .= '</entity_profile>' . "\n";
    ets_cache_tracking($item_export);
    ets_cache_export('total_attribute_combination', $ik);
    if ($ik <= $ikCached)
        return false;
    return $xml_output;
}

function ets_oneclicktomigrate_get_id_attribute($dataAttributes, $group_name, $attribute_name)
{
    if (!$dataAttributes || !$attribute_name)
        return 0;
    $id_attribute = 0;
    $group_name = strtolower($group_name);
    $attribute_name = strtolower($attribute_name);
    foreach ($dataAttributes as $key => $dataAttribute) {
        if ($dataAttribute) {
            foreach ($dataAttribute as $attribute) {
                $id_attribute++;
                if (strtolower($key) == $group_name && strtolower($attribute) == $attribute_name)
                    return $id_attribute;
            }
        }
    }
    return 0;
}

function ets_oneclicktomigrate_export_attribute_group($args = array())
{
    $dataAttributes = ets_get_cache_attributes();
    if (!$dataAttributes) {
        $getAll = ets_oneclicktomigrate_export_get_attributes($args);
        if (isset($getAll['att']) && $getAll['att'])
            $dataAttributes = (array)$getAll['att'];
    }
    $item_export = ets_get_cache_tracking();
    ets_cache_export('export_table', 'attribute_group');
    $time = time();

    $xml_output = '<?xml version="1.0" encoding="UTF-8"?>' . "\n";
    $xml_output .= '<entity_profile>' . "\n";
    $auto_increment = 0;
    if ($dataAttributes) {
        foreach ($dataAttributes as $key => $attribute_group) {
            $auto_increment++;
            $xml_output .= '<attribute_group>' . "\n";
            $xml_output .= '<id_attribute_group><![CDATA[' . $auto_increment . ']]></id_attribute_group>' . "\n";
            $xml_output .= '<is_color_group><![CDATA[0]]></is_color_group>' . "\n";
            $xml_output .= '<group_type><![CDATA[select]]></group_type>' . "\n";
            $xml_output .= '<datalanguage>' . "\n";
            $xml_output .= '<name><![CDATA[' . str_replace(array(',', ';', ':', '-', '.'), ' ', $key) . ']]></name>' . "\n";
            $xml_output .= '<public_name><![CDATA[' . str_replace(array(',', ';', ':', '-', '.'), ' ', $key) . ']]></public_name>' . "\n";
            $xml_output .= '</datalanguage>' . "\n";
            $xml_output .= '</attribute_group>' . "\n";
            ets_cache_tracking(++$item_export, $time);
        }
        unset($attribute_group);
    }
    $xml_output .= '</entity_profile>' . "\n";
    ets_cache_tracking($item_export);
    ets_cache_export('total_attribute_group', $auto_increment);
    if (!$auto_increment)
        return false;
    return $xml_output;
}

function ets_oneclicktomigrate_export_attribute($args = array())
{
    $dataAttributes = ets_get_cache_attributes();
    if (!$dataAttributes) {
        $getAll = ets_oneclicktomigrate_export_get_attributes($args);
        if (isset($getAll['att']) && $getAll['att'])
            $dataAttributes = (array)$getAll['att'];
    }
    $item_export = ets_get_cache_tracking();
    ets_cache_export('export_table', 'attribute');
    $time = time();

    $xml_output = '<?xml version="1.0" encoding="UTF-8"?>' . "\n";
    $xml_output .= '<entity_profile>' . "\n";
    $auto_increment = $group_auto_increment = 0;
    if ($dataAttributes) {
        foreach ($dataAttributes as $key => $attributes) {
            $group_auto_increment++;
            if ($attributes) {
                foreach ($attributes as $attribute) {
                    $auto_increment++;
                    $xml_output .= '<attribute>' . "\n";
                    $xml_output .= '<id_attribute><![CDATA[' . $auto_increment . ']]></id_attribute>' . "\n";
                    $xml_output .= '<id_attribute_group><![CDATA[' . $group_auto_increment . ']]></id_attribute_group>' . "\n";
                    $xml_output .= '<color><![CDATA[]]></color>' . "\n";
                    $xml_output .= '<position><![CDATA[' . $auto_increment . ']]></position>' . "\n";
                    $xml_output .= '<datalanguage>' . "\n";
                    $xml_output .= '<name><![CDATA[' . str_replace(array(',', ';', ':', '-', '.'), ' ', $attribute) . ']]></name>' . "\n";
                    $xml_output .= '</datalanguage>' . "\n";
                    $xml_output .= '</attribute>' . "\n";
                    ets_cache_tracking(++$item_export, $time);
                }
            }
        }
        unset($attributes, $group_auto_increment);
    }
    $xml_output .= '</entity_profile>' . "\n";
    ets_cache_tracking($item_export);
    ets_cache_export('total_attribute', $auto_increment);
    if (!$auto_increment)
        return false;
    return $xml_output;
}

//end export attribute.

function ets_oneclicktomigrate_export_feature($args = array())
{
    $dataFeatures = ets_get_cache_features();
    if (!$dataFeatures) {
        $getAll = ets_oneclicktomigrate_export_get_attributes($args);
        if (isset($getAll['fea']) && $getAll['fea'])
            $dataFeatures = (array)$getAll['fea'];
    }
    $item_export = ets_get_cache_tracking();
    ets_cache_export('export_table', 'feature');
    $time = time();

    $xml_output = '<?xml version="1.0" encoding="UTF-8"?>' . "\n";
    $xml_output .= '<entity_profile>' . "\n";
    $auto_increment = 0;
    if ($dataFeatures) {
        foreach ($dataFeatures as $key => $feature) {
            $auto_increment++;
            $xml_output .= '<feature>' . "\n";
            $xml_output .= '<id_feature><![CDATA[' . (int)$auto_increment . ']]></id_feature>' . "\n";
            $xml_output .= '<position><![CDATA[' . (int)$auto_increment . ']]></position>' . "\n";
            $xml_output .= '<datalanguage>' . "\n";
            $xml_output .= '<name><![CDATA[' . str_replace(array(',', ';', ':', '-', '.'), ' ', $key) . ']]></name>' . "\n";
            $xml_output .= '</datalanguage>' . "\n";
            $xml_output .= '</feature>' . "\n";
            ets_cache_tracking(++$item_export, $time);
        }
        unset($attribute_group);
    }
    $xml_output .= '</entity_profile>' . "\n";
    ets_cache_tracking($item_export);
    ets_cache_export('total_feature', $auto_increment);
    if (!$auto_increment)
        return false;
    return $xml_output;
}

function ets_oneclicktomigrate_export_feature_value($args = array())
{
    $dataFeatures = ets_get_cache_features();
    if (!$dataFeatures) {
        $getAll = ets_oneclicktomigrate_export_get_attributes($args);
        if (isset($getAll['fea']) && $getAll['fea'])
            $dataFeatures = (array)$getAll['fea'];
    }
    $item_export = ets_get_cache_tracking();
    ets_cache_export('export_table', 'feature_value');
    $time = time();

    $xml_output = '<?xml version="1.0" encoding="UTF-8"?>' . "\n";
    $xml_output .= '<entity_profile>' . "\n";
    $auto_increment = $group_auto_increment = 0;
    if ($dataFeatures) {
        foreach ($dataFeatures as $key => $features) {
            $group_auto_increment++;
            if ($features) {
                foreach ($features as $feature) {
                    $auto_increment++;
                    $xml_output .= '<feature_value>' . "\n";
                    $xml_output .= '<id_feature_value><![CDATA[' . $auto_increment . ']]></id_feature_value>' . "\n";
                    $xml_output .= '<id_feature><![CDATA[' . $group_auto_increment . ']]></id_feature>' . "\n";
                    $xml_output .= '<custom><![CDATA[0]]></custom>' . "\n";
                    $xml_output .= '<datalanguage>' . "\n";
                    $xml_output .= '<value><![CDATA[' . str_replace(array(',', ';', ':', '-', '.'), ' ', $feature) . ']]></value>' . "\n";
                    $xml_output .= '</datalanguage>' . "\n";
                    $xml_output .= '</feature_value>' . "\n";
                    ets_cache_tracking(++$item_export, $time);
                }
            }
        }
        unset($attributes, $group_auto_increment);
    }
    $xml_output .= '</entity_profile>' . "\n";
    ets_cache_tracking($item_export);
    ets_cache_export('total_feature_value', $auto_increment);
    if (!$auto_increment)
        return false;
    return $xml_output;
}

function ets_oneclicktomigrate_export_feature_product($args = array())
{
    $dataFeatures = ets_get_cache_features();
    if (!$dataFeatures) {
        $getAll = ets_oneclicktomigrate_export_get_attributes($args);
        if (isset($getAll['fea']) && $getAll['fea'])
            $dataFeatures = (array)$getAll['fea'];
    }
    $paged = -1;
    if (isset($args['paged']))
        $paged = (int)$args['paged'];
    $products = ets_get_cache_product($paged);
    if (!$products)
        $products = ets_oneclicktomigrate_get_products($args);
    if (!$products) {
        ets_cache_export('feature_product', 1);
        ets_return_json(array('export' => 'featureproduct-end.xml'));
    }
    $item_export = ets_get_cache_tracking();
    ets_cache_export('export_table', 'feature_product');
    $time = time();

    $xml_output = '<?xml version="1.0" encoding="UTF-8"?>' . "\n";
    $xml_output .= '<entity_profile>' . "\n";
    $ik = ($ikCached = (int)ets_get_cache_export('total_feature_product')) ? $ikCached : 0;
    if ($products && $dataFeatures) {
        foreach ($products as $id_product) {
            $product = new WC_Product($id_product);
            $features = $product->get_attributes();
            if ($features) {
                $dataFeature = array();
                foreach ($features as $feature) {
                    ets_oneclicktomigrate_get_features($id_product, $feature, $dataFeature);
                }
                if ($dataFeature) {
                    $ikFeature = 0;
                    $list_feature = array();
                    foreach ($dataFeature as $key => $productFeature) {
                        if ($productFeature) {
                            foreach ($productFeature as $feature_value) {
                                $list_feature[] = ets_oneclicktomigrate_get_id_feature($dataFeatures, $key, $feature_value);
                            }
                        }
                    }
                    if ($list_feature) {
                        foreach ($list_feature as $feature_product) {
                            $xml_output .= '<feature_product>' . "\n";
                            $xml_output .= '<id_product><![CDATA[' . (int)$id_product . ']]></id_product>' . "\n";
                            $xml_output .= '<id_feature><![CDATA[' . (int)$feature_product['id_feature'] . ']]></id_feature>' . "\n";
                            $xml_output .= '<id_feature_value><![CDATA[' . (int)$feature_product['id_feature_value'] . ']]></id_feature_value>' . "\n";
                            $xml_output .= '</feature_product>' . "\n";
                            $ikFeature++;
                        }
                        ets_cache_tracking(++$item_export, $time);
                    }
                    if ($ikFeature > 0)
                        $ik++;
                }
            }
        }
    }
    $xml_output .= '</entity_profile>' . "\n";
    ets_cache_tracking($item_export);
    ets_cache_export('total_feature_product', $ik);
    if ($ik <= $ikCached)
        return false;
    return $xml_output;
}

function ets_oneclicktomigrate_get_id_feature($dataFeatures, $feature, $feature_value)
{
    if (!$dataFeatures || !$feature_value)
        return 0;
    $id_feature = 0;
    $id_feature_value = 0;
    foreach ($dataFeatures as $key => $dataFeature) {
        $id_feature++;
        if ($dataFeature) {
            foreach ($dataFeature as $fea) {
                $id_feature_value++;
                if ($key == $feature && $fea == $feature_value) {
                    return array(
                        'id_feature' => $id_feature,
                        'id_feature_value' => $id_feature_value,
                    );
                }
            }
        }
    }
    return array(
        'id_feature' => $id_feature,
        'id_feature_value' => $id_feature_value,
    );
}

function ets_oneclicktomigrate_get_attributes($key, $attribute, &$dataAttributes)
{
    if ($key && $attribute) {
        $taxonomy = str_replace('pa_', '', $key);
        if (!(isset($dataAttributes[$taxonomy]))) {
            $dataAttributes[$taxonomy] = $attribute;
        } elseif ($attribute) {
            foreach ($attribute as $att) {
                if (!in_array($att, $dataAttributes[$taxonomy])) {
                    $dataAttributes[$taxonomy][] = $att;
                }
            }
        }
    }
}

function ets_oneclicktomigrate_get_features($id_product, $feature, &$dataFeatures)
{
    if (method_exists($feature, 'get_data')) {
        $data = $feature->get_data();
        if (isset($data['is_taxonomy']) && $data['is_taxonomy'] && ($terms = $feature->get_terms())) {
            foreach ($terms as $item) {
                $taxonomy = str_replace('pa_', '', $item->taxonomy);
                if (!isset($dataFeatures[$taxonomy]))
                    $dataFeatures[$taxonomy] = array();
                if (!in_array($item->name, $dataFeatures[$taxonomy]))
                    $dataFeatures[$taxonomy][] = $item->name;
            }
        } elseif ($data) {
            if (!isset($dataFeatures[$data['name']]))
                $dataFeatures[$data['name']] = $data['options'];
            else
                $dataFeatures[$data['name']] = array_merge($data['options'], $dataFeatures[$data['name']]);
        }
    } else {
        if (isset($feature['is_taxonomy']) && $feature['is_taxonomy'] && ($terms = wp_get_post_terms($id_product, $feature['name'], 'all'))) {
            foreach ($terms as $term) {
                $taxonomy = str_replace('pa_', '', $term->taxonomy);
                if (!isset($dataFeatures[$taxonomy]))
                    $dataFeatures[$taxonomy] = array();
                if (!in_array($term->name, $dataFeatures[$taxonomy]))
                    $dataFeatures[$taxonomy][] = $term->name;
            }
        } elseif (!empty($feature)) {
            if (!isset($dataFeatures[$feature['name']]))
                $dataFeatures[$feature['name']] = $feature['options'];
            else
                $dataFeatures[$feature['name']] = array_merge($feature['options'], $dataFeatures[$feature['name']]);
        }
    }
}

function ets_oneclicktomigrate_export_get_attributes($args = array())
{
    $paged = -1;
    if (isset($args['paged']))
        $paged = (int)$args['paged'];
    $products = ets_get_cache_product($paged);
    if (!$products)
        $products = ets_oneclicktomigrate_get_products($args);
    if (!$products) {
        ets_cache_exports(array('all_attribute' => 1, 'product_paged' => 0));
        ets_return_json(array('export' => 'getAttribute-end.xml'));
    }
    $dataAttributes = ($atts = ets_get_cache_attributes()) ? (array)$atts : array();
    $dataFeatures = ($feas = ets_get_cache_features()) ? (array)$feas : array();

    foreach ($products as $id_product) {
        $product = new WC_Product($id_product);
        $product_variation = new WC_Product_Variable($id_product);
        //get_attribute_product
        if (($attributes = $product_variation->get_variation_attributes())) {
            foreach ($attributes as $key => $attribute) {
                ets_oneclicktomigrate_get_attributes($key, $attribute, $dataAttributes);
            }
        }
        //get feature product.
        if (($features = $product->get_attributes())) {
            foreach ($features as $feature) {
                ets_oneclicktomigrate_get_features($id_product, $feature, $dataFeatures);
            }
        }
    }
    ets_cache_export('product_paged', ($paged < 0 ? 0 : $paged));
    return array(
        'fea' => $dataFeatures,
        'att' => $dataAttributes,
    );
}

function ets_oneclicktomigrate_export_tags()
{
    $tags = get_terms(array('hide_empty' => false, 'taxonomy' => 'product_tag'));

    $item_export = ets_get_cache_tracking();
    ets_cache_export('export_table', 'tag');
    $time = time();

    $xml_output = '<?xml version="1.0" encoding="UTF-8"?>' . "\n";
    $xml_output .= '<entity_profile>' . "\n";
    $ikCount = 0;
    if ($tags) {
        foreach ($tags as $tag) {
            $ikCount++;
            $xml_output .= '<tag>' . "\n";
            $xml_output .= '<id_tag><![CDATA[' . (int)$tag->term_id . ']]></id_tag>' . "\n";
            $xml_output .= '<id_lang><![CDATA[0]]></id_lang>' . "\n";
            $xml_output .= '<name><![CDATA[' . $tag->name . ']]></name>' . "\n";
            $xml_output .= '</tag>' . "\n";
            ets_cache_tracking(++$item_export, $time);
        }
    }
    $xml_output .= '</entity_profile>';
    ets_cache_tracking($item_export);
    ets_cache_export('total_tag', $ikCount);
    if ($ikCount <= 0)
        return false;
    return $xml_output;
}

//cache_export.
function ets_cache_exports($cache_export)
{
    if (!@is_dir(($cacheFile = ETS_WP_DATA_XML . 'cache/')))
        @mkdir($cacheFile, 0755);
    $exports = array();
    if (@file_exists($cacheFile . 'exports.json')) {
        $exports = (array)json_decode(@file_get_contents($cacheFile . 'exports.json'));
    }
    if ($cache_export) {
        foreach ($cache_export as $key => $value) {
            $exports[$key] = $value;
        }
    }
    if ($exports) {
        @file_put_contents($cacheFile . 'exports.json', json_encode($exports), LOCK_EX);
    }
}

function ets_cache_export($key, $value)
{
    if (!@is_dir(($cacheFile = ETS_WP_DATA_XML . 'cache/')))
        @mkdir($cacheFile, 0755);
    $exports = array();
    if (@file_exists($cacheFile . 'exports.json')) {
        $exports = (array)json_decode(@file_get_contents($cacheFile . 'exports.json'));
    }
    $exports[$key] = $value;
    if ($exports) {
        @file_put_contents($cacheFile . 'exports.json', json_encode($exports), LOCK_EX);
    }
}

function ets_get_cache_export($key = null)
{
    if (@file_exists(($cacheJson = ETS_WP_DATA_XML . 'cache/exports.json'))) {
        $exports = (array)json_decode(@file_get_contents($cacheJson));
        if ($key == 'all') {
            return $exports;
        }
        if ($exports) {
            foreach ($exports as $unique => $export) {
                if ($unique == $key) {
                    return $export;
                }
            }
        }
    }
    return false;
}

//end cache_export.
function ets_oneclicktomigrate_export_product_tags($args = array())
{
    $paged = -1;
    if (isset($args['paged']))
        $paged = (int)$args['paged'];
    $products = ets_get_cache_product($paged);
    if (!$products)
        $products = ets_oneclicktomigrate_get_products($args);
    if (!$products) {
        ets_cache_export('product_tag', 1);
        ets_return_json(array('export' => 'producttag-end.xml'));
    }
    $item_export = ets_get_cache_tracking();
    ets_cache_export('export_table', 'product_tag');
    $time = time();

    $xml_output = '<?xml version="1.0" encoding="UTF-8"?>' . "\n";
    $xml_output .= '<entity_profile>' . "\n";
    $ik = ($ikCached = (int)ets_get_cache_export('total_product_tag')) ? (int)$ikCached : 0;
    foreach ($products as $id_product) {
        $product = new WC_Product($id_product);
        if (method_exists($product, 'get_tag_ids'))
            $tags = $product->get_tag_ids();
        else
            $tags = $product->get_tags();
        if ($tags) {
            foreach ($tags as $tag) {
                $ik++;
                $xml_output .= '<product_tag>' . "\n";
                $xml_output .= '<id_product><![CDATA[' . (int)$id_product . ']]></id_product>' . "\n";
                $xml_output .= '<id_tag><![CDATA[' . (isset($tag->term_id) ? $tag->term_id : $tag) . ']]></id_tag>' . "\n";
                $xml_output .= '</product_tag>' . "\n";
                ets_cache_tracking(++$item_export, $time);
            }
        }
        unset($tags, $product);
    }
    $xml_output .= '</entity_profile>' . "\n";
    ets_cache_tracking($item_export);
    ets_cache_exports(array('total_product_tag' => $ik, 'tag_paged' => ($paged < 0 ? 0 : $paged)));
    if ($ik <= $ikCached)
        ets_return_json(array('export' => 'producttag.xml'));
    return $xml_output;
}

function ets_oneclicktomigrate_export_posts()
{
    $posts = get_posts();

    $item_export = ets_get_cache_tracking();
    ets_cache_export('export_table', 'post');
    $time = time();

    $xml_output = '<?xml version="1.0" encoding="UTF-8"?>' . "\n";
    $xml_output .= '<entity_profile>' . "\n";
    $ikCount = 0;
    if ($posts) {
        foreach ($posts as $post) {
            $ikCount++;
            $category_detail = wp_get_post_categories($post->ID);
            $xml_output .= '<cms>' . "\n";
            $xml_output .= '<id_cms><![CDATA[' . (int)$post->ID . ']]></id_cms>' . "\n";
            $xml_output .= '<id_cms_category><![CDATA[' . ($category_detail ? $category_detail[0] : 0) . ']]></id_cms_category>' . "\n";
            $xml_output .= '<position><![CDATA[0]]></position>' . "\n";
            $xml_output .= '<active><![CDATA[' . ($post->post_status == 'publish' ? 1 : 0) . ']]></active>' . "\n";
            $xml_output .= '<datalanguage>' . "\n";
            $xml_output .= '<meta_title><![CDATA[' . $post->post_title . ']]></meta_title>' . "\n";
            $xml_output .= '<meta_description><![CDATA[' . (get_post_meta($post->ID, '_yoast_wpseo_metadesc', true) ? get_post_meta($post->ID, '_yoast_wpseo_metadesc', true) : (get_post_meta($post->ID, '_aioseop_description', true) ? get_post_meta($post->ID, '_aioseop_description', true) : (get_post_meta($post->ID, '_genesis_description', true) ? get_post_meta($post->ID, '_genesis_description', true) : ''))) . ']]></meta_description>' . "\n";
            $xml_output .= '<meta_keywords><![CDATA[' . (get_post_meta($post->ID, '_yoast_wpseo_focuskw', true) ? get_post_meta($post->ID, '_yoast_wpseo_focuskw', true) : (get_post_meta($post->ID, '_aioseop_keywords', true) ? get_post_meta($post->ID, '_aioseop_keywords', true) : '')) . ']]></meta_keywords>' . "\n";
            $xml_output .= '<content><![CDATA[' . $post->post_content . ']]></content>' . "\n";
            $xml_output .= '<link_rewrite><![CDATA[' . $post->post_name . ']]></link_rewrite>' . "\n";
            $xml_output .= '</datalanguage>' . "\n";
            $xml_output .= '</cms>' . "\n";
            ets_cache_tracking(++$item_export, $time);
        }
    }
    $xml_output .= '</entity_profile>' . "\n";
    ets_cache_tracking($item_export);
    ets_cache_export('total_post', $ikCount);
    if ($ikCount <= 0)
        return false;
    return $xml_output;
}

function ets_oneclicktomigrate_export_pages()
{
    $item_export = ets_get_cache_tracking();
    ets_cache_export('export_table', 'page');
    $time = time();

    $xml_output = '<?xml version="1.0" encoding="UTF-8"?>' . "\n";
    $xml_output .= '<entity_profile>' . "\n";
    $count = 0;
    if ($pages = get_pages()) {
        foreach ($pages as $page) {
            if ($page->post_content && $page->post_content != '[woocommerce_cart]' && $page->post_content != '[woocommerce_checkout]' && $page->post_content != '[woocommerce_my_account]') {
                $count++;
                $xml_output .= '<cms>' . "\n";
                $xml_output .= '<id_cms><![CDATA[' . (int)$page->ID . ']]></id_cms>' . "\n";
                $xml_output .= '<id_cms_category><![CDATA[0]]></id_cms_category>' . "\n";
                $xml_output .= '<position><![CDATA[0]]></position>' . "\n";
                $xml_output .= '<active><![CDATA[' . ($page->post_status == 'publish' ? 1 : 0) . ']]></active>' . "\n";
                $xml_output .= '<datalanguage>' . "\n";
                $xml_output .= '<meta_title><![CDATA[' . $page->post_title . ']]></meta_title>' . "\n";
                $xml_output .= '<meta_description><![CDATA[' . (get_post_meta($page->ID, '_yoast_wpseo_metadesc', true) ? get_post_meta($page->ID, '_yoast_wpseo_metadesc', true) : (get_post_meta($page->ID, '_aioseop_description', true) ? get_post_meta($page->ID, '_aioseop_description', true) : (get_post_meta($page->ID, '_genesis_description', true) ? get_post_meta($page->ID, '_genesis_description', true) : ''))) . ']]></meta_description>' . "\n";
                $xml_output .= '<meta_keywords><![CDATA[' . (get_post_meta($page->ID, '_yoast_wpseo_focuskw', true) ? get_post_meta($page->ID, '_yoast_wpseo_focuskw', true) : (get_post_meta($page->ID, '_aioseop_keywords', true) ? get_post_meta($page->ID, '_aioseop_keywords', true) : '')) . ']]></meta_keywords>' . "\n";
                $xml_output .= '<content><![CDATA[' . $page->post_content . ']]></content>' . "\n";
                $xml_output .= '<link_rewrite><![CDATA[' . $page->post_name . ']]></link_rewrite>' . "\n";
                $xml_output .= '</datalanguage>' . "\n";
                $xml_output .= '</cms>' . "\n";
                ets_cache_tracking(++$item_export, $time);
            }
        }
    }
    $xml_output .= '</entity_profile>' . "\n";
    ets_cache_tracking($item_export);
    ets_cache_export('total_page', $count);
    if (!$count)
        return false;
    return $xml_output;
}

function ets_oneclicktomigrate_recursive_cms_category($categories, &$xml_output, &$ik, &$time)
{
    $item_export = ets_get_cache_tracking();
    if ($categories) {
        foreach ($categories as $category) {
            $ik++;
            $xml_output .= '<cms_category>' . "\n";
            $xml_output .= '<id_cms_category><![CDATA[' . (int)$category->term_id . ']]></id_cms_category>' . "\n";
            $xml_output .= '<id_parent><![CDATA[' . (int)$category->parent . ']]></id_parent>' . "\n";
            $xml_output .= '<woocommerce><![CDATA[1]]></woocommerce>' . "\n";
            $xml_output .= '<level_depth><![CDATA[0]]></level_depth>' . "\n";
            $xml_output .= '<active><![CDATA[1]]></active>' . "\n";
            $xml_output .= '<date_add><![CDATA[' . date('Y-m-d h:i:s', time()) . ']]></date_add>' . "\n";
            $xml_output .= '<date_upd><![CDATA[' . date('Y-m-d h:i:s', time()) . ']]></date_upd>' . "\n";
            $xml_output .= '<position><![CDATA[0]]></position>' . "\n";
            $xml_output .= '<datalanguage>' . "\n";
            $xml_output .= '<name><![CDATA[' . $category->name . ']]></name>' . "\n";
            $xml_output .= '<description><![CDATA[' . $category->description . ']]></description>' . "\n";
            $xml_output .= '<link_rewrite><![CDATA[' . $category->slug . ']]></link_rewrite>' . "\n";
            $xml_output .= '<meta_description><![CDATA[' . (get_post_meta($category->term_id, '_yoast_wpseo_metadesc', true) ? get_post_meta($category->term_id, '_yoast_wpseo_metadesc', true) : (get_post_meta($category->term_id, '_aioseop_description', true) ? get_post_meta($category->term_id, '_aioseop_description', true) : (get_post_meta($category->term_id, '_genesis_description', true) ? get_post_meta($category->term_id, '_genesis_description', true) : ''))) . ']]></meta_description>' . "\n";
            $xml_output .= '<meta_keywords><![CDATA[' . (get_post_meta($category->term_id, '_yoast_wpseo_focuskw', true) ? get_post_meta($category->term_id, '_yoast_wpseo_focuskw', true) : (get_post_meta($category->term_id, '_aioseop_keywords', true) ? get_post_meta($category->term_id, '_aioseop_keywords', true) : '')) . ']]></meta_keywords>' . "\n";
            $xml_output .= '<meta_title><![CDATA[' . (get_post_meta($category->term_id, '_yoast_wpseo_title', true) ? get_post_meta($category->term_id, '_yoast_wpseo_title', true) : (get_post_meta($category->term_id, '_aioseop_title', true) ? get_post_meta($category->term_id, '_aioseop_title', true) : (get_post_meta($category->term_id, '_genesis_title', true) ? get_post_meta($category->term_id, '_genesis_title', true) : ''))) . ']]></meta_title>' . "\n";
            $xml_output .= '</datalanguage>' . "\n";
            $xml_output .= '</cms_category>' . "\n";
            ets_cache_tracking(++$item_export, $time);
            if (!empty($category->children))
                ets_oneclicktomigrate_recursive_cms_category($category->children, $xml_output, $ik, $time);
        }
    }
    ets_cache_tracking($item_export);
    return $xml_output;
}

function ets_oneclicktomigrate_export_cms_category()
{
    $categories = ets_oneclicktomigrate_get_cms_categories();

    ets_cache_export('export_table', 'cms_category');
    $time = time();

    $xml_output = '<?xml version="1.0" encoding="UTF-8"?>' . "\n";
    $xml_output .= '<entity_profile>' . "\n";
    $count = 0;
    if ($categories)
        ets_oneclicktomigrate_recursive_cms_category($categories, $xml_output, $count, $time);
    $xml_output .= '</entity_profile>' . "\n";
    ets_cache_export('total_cms_category', $count);
    if (!$count)
        return false;
    return $xml_output;
}

function ets_oneclicktomigrate_export_countries()
{
    $countries = new WC_Countries();

    $item_export = ets_get_cache_tracking();
    ets_cache_export('export_table', 'country');
    $time = time();

    $xml_output = '<?xml version="1.0" encoding="UTF-8"?>' . "\n";
    $xml_output .= '<entity_profile>' . "\n";
    $count = 0;
    if (($countries = $countries->get_countries())) {
        $id_country = 1;
        foreach ($countries as $key => $country) {
            $count++;
            $xml_output .= '<country>' . "\n";
            $xml_output .= '<id_country><![CDATA[' . (int)$id_country . ']]></id_country>' . "\n";
            $xml_output .= '<id_zone><![CDATA[' . (int)ets_oneclicktomigrate_get_id_zone($key) . ']]></id_zone>' . "\n";
            $xml_output .= '<woocommerce><![CDATA[1]]></woocommerce>' . "\n";
            $xml_output .= '<id_currency><![CDATA[0]]></id_currency>' . "\n";
            $xml_output .= '<iso_code><![CDATA[' . $key . ']]></iso_code>' . "\n";
            $xml_output .= '<call_prefix><![CDATA[0]]></call_prefix>' . "\n";
            $xml_output .= '<active><![CDATA[1]]></active>' . "\n";
            $xml_output .= '<contains_states><![CDATA[0]]></contains_states>' . "\n";
            $xml_output .= '<need_identification_number><![CDATA[0]]></need_identification_number>' . "\n";
            $xml_output .= '<need_zip_code><![CDATA[0]]></need_zip_code>' . "\n";
            $xml_output .= '<zip_code_format><![CDATA[NNNNN]]></zip_code_format>' . "\n";
            $xml_output .= '<display_tax_label><![CDATA[1]]></display_tax_label>' . "\n";
            $xml_output .= '<datalanguage>' . "\n";
            $xml_output .= '<name><![CDATA[' . $country . ']]></name>' . "\n";//html_entity_decode()
            $xml_output .= '</datalanguage>' . "\n";
            $xml_output .= '</country>' . "\n";
            $id_country++;
            ets_cache_tracking(++$item_export, $time);
        }
    }
    $xml_output .= '</entity_profile>' . "\n";
    ets_cache_tracking($item_export);
    ets_cache_export('total_country', $count);
    if (!$count)
        return false;
    return $xml_output;
}

function ets_oneclicktomigrate_get_id_zone($iso_code)
{
    global $wpdb;
    $zones = $wpdb->get_results("
        SELECT * FROM {$wpdb->prefix}woocommerce_shipping_zones z 
        LEFT JOIN {$wpdb->prefix}woocommerce_shipping_zone_locations zl ON (z.zone_id = zl.zone_id) 
        WHERE zl.location_code='" . $iso_code . "' AND zl.location_type='country'
        ORDER BY z.zone_order ASC
    ");
    if (count($zones))
        return $zones[0]->zone_id + 1;
    return 1;
}

function ets_oneclicktomigrate_export_zones()
{
    global $wpdb;
    $zones = $wpdb->get_results("SELECT * FROM {$wpdb->prefix}woocommerce_shipping_zones z ORDER BY z.zone_id ASC");

    $item_export = ets_get_cache_tracking();
    ets_cache_export('export_table', 'zone');
    $time = time();

    $xml_output = '<?xml version="1.0" encoding="UTF-8"?>' . "\n";
    $xml_output .= '<entity_profile>' . "\n";
    $xml_output .= '<zone>' . "\n";
    $xml_output .= '<id_zone><![CDATA[1]]></id_zone>' . "\n";
    $xml_output .= '<name><![CDATA[Zone other]]></name>' . "\n";
    $xml_output .= '<active><![CDATA[1]]></active>' . "\n";
    $xml_output .= '</zone>' . "\n";
    ets_cache_tracking(++$item_export, $time);
    $count = 1;
    if ($zones) {
        foreach ($zones as $zone) {
            $count++;
            $xml_output .= '<zone>' . "\n";
            $xml_output .= '<id_zone><![CDATA[' . ($zone->zone_id + 1) . ']]></id_zone>' . "\n";
            $xml_output .= '<name><![CDATA[' . $zone->zone_name . ']]></name>' . "\n";
            $xml_output .= '<active><![CDATA[1]]></active>' . "\n";
            $xml_output .= '</zone>' . "\n";
            ets_cache_tracking(++$item_export, $time);
        }
    }
    $xml_output .= '</entity_profile>' . "\n";
    ets_cache_tracking($item_export);
    ets_cache_export('total_zone', $count);
    if (!$count)
        return false;
    return $xml_output;
}

function ets_oneclicktomigrate_export_carrier_zone()
{
    global $wpdb;
    $zones = $wpdb->get_results("SELECT * FROM {$wpdb->prefix}woocommerce_shipping_zone_methods z WHERE is_enabled = 1 GROUP BY z.zone_id, z.method_id");

    $item_export = ets_get_cache_tracking();
    ets_cache_export('export_table', 'carrier_zone');
    $time = time();

    $xml_output = '<?xml version="1.0" encoding="UTF-8"?>' . "\n";
    $xml_output .= '<entity_profile>' . "\n";
    $count = 0;
    if ($zones) {
        foreach ($zones as $zone) {
            $count++;
            $xml_output .= '<carrier_zone>' . "\n";
            $xml_output .= '<id_carrier><![CDATA[' . ets_oneclicktomigrate_get_id_carrier($zone->method_id) . ']]></id_carrier>' . "\n";
            $xml_output .= '<id_zone><![CDATA[' . ($zone->zone_id + 1) . ']]></id_zone>' . "\n";
            $xml_output .= '</carrier_zone>' . "\n";
            ets_cache_tracking(++$item_export, $time);
        }
    }
    for ($i = 1; $i <= 3; $i++) {
        $count++;
        $xml_output .= '<carrier_zone>' . "\n";
        $xml_output .= '<id_carrier><![CDATA[' . $i . ']]></id_carrier>' . "\n";
        $xml_output .= '<id_zone><![CDATA[1]]></id_zone>' . "\n";
        $xml_output .= '</carrier_zone>' . "\n";
        ets_cache_tracking(++$item_export, $time);
    }

    $xml_output .= '</entity_profile>' . "\n";
    ets_cache_tracking($item_export);
    ets_cache_export('total_carrier_zone', $count);
    if (!$count)
        return false;
    return $xml_output;
}

function ets_oneclicktomigrate_get_id_country($iso_code)
{
    $wc_countries = new WC_Countries();
    $countries = $wc_countries->get_countries();
    if ($countries) {
        $auto_increment = 0;
        foreach ($countries as $key => $country) {
            $auto_increment++;
            if ($key == $iso_code)
                return $auto_increment;
        }
    }
    return 0;
}

function ets_oneclicktomigrate_export_carriers()
{
    $shipping_class = new WC_Shipping();

    $item_export = ets_get_cache_tracking();
    ets_cache_export('export_table', 'carrier');
    $time = time();

    $xml_output = '<?xml version="1.0" encoding="UTF-8"?>' . "\n";
    $xml_output .= '<entity_profile>' . "\n";
    $auto_increment = 0;
    if (($shipping_methods = $shipping_class->get_shipping_methods())) {
        foreach ($shipping_methods as $key => $shipping) {
            $auto_increment++;
            $xml_output .= '<carrier>' . "\n";
            $xml_output .= '<id_carrier><![CDATA[' . (int)$auto_increment . ']]></id_carrier>' . "\n";
            $xml_output .= '<id_tax_rules_group><![CDATA[0]]></id_tax_rules_group>' . "\n";
            $xml_output .= '<name><![CDATA[' . $shipping->method_title . ']]></name>' . "\n";
            $xml_output .= '<url><![CDATA[]]></url>' . "\n";
            $xml_output .= '<active><![CDATA[' . ($shipping->enabled == 'yes' ? 1 : 0) . ']]></active>' . "\n";
            $xml_output .= '<deleted><![CDATA[0]]></deleted>' . "\n";
            $xml_output .= '<shipping_handling><![CDATA[0]]></shipping_handling>' . "\n";
            $xml_output .= '<range_behavior><![CDATA[0]]></range_behavior>' . "\n";
            $xml_output .= '<is_module><![CDATA[0]]></is_module>' . "\n";
            $xml_output .= '<is_free><![CDATA[' . ($key == 'free_shipping' ? 1 : 0) . ']]></is_free>' . "\n";
            $xml_output .= '<shipping_external><![CDATA[0]]></shipping_external>' . "\n";
            $xml_output .= '<need_range><![CDATA[0]]></need_range>' . "\n";
            $xml_output .= '<external_module_name><![CDATA[]]></external_module_name>' . "\n";
            $xml_output .= '<shipping_method><![CDATA[2]]></shipping_method>' . "\n";
            $xml_output .= '<datalanguage>' . "\n";
            $xml_output .= '<delay><![CDATA[' . ($shipping->method_description ? $shipping->method_description : $shipping->method_title) . ']]></delay>' . "\n";
            $xml_output .= '</datalanguage>' . "\n";
            $xml_output .= '</carrier>' . "\n";
            ets_cache_tracking(++$item_export, $time);
        }
    }
    $xml_output .= '</entity_profile>' . "\n";
    ets_cache_tracking($item_export);
    ets_cache_export('total_carrier', $auto_increment);
    if (!$auto_increment)
        return false;
    return $xml_output;
}

function ets_oneclicktomigrate_export_range_price()
{
    $shipping_class = new WC_Shipping();

    $item_export = ets_get_cache_tracking();
    ets_cache_export('export_table', 'range_price');
    $time = time();

    $xml_output = '<?xml version="1.0" encoding="UTF-8"?>' . "\n";
    $xml_output .= '<entity_profile>' . "\n";
    $auto_increment = 0;
    if (($shippings = $shipping_class->get_shipping_methods())) {
        foreach ($shippings as $key => $shipping) {
            if ($key != 'free_shipping') {
                $auto_increment++;
                $xml_output .= '<range_price>' . "\n";
                $xml_output .= '<id_range_price><![CDATA[' . (int)$auto_increment . ']]></id_range_price>' . "\n";
                $xml_output .= '<id_carrier><![CDATA[' . $auto_increment . ']]></id_carrier>' . "\n";
                $xml_output .= '<delimiter1><![CDATA[0.000000]]></delimiter1>' . "\n";
                $xml_output .= '<delimiter2><![CDATA[0.000000]]></delimiter2>' . "\n";
                $xml_output .= '</range_price>' . "\n";
                ets_cache_tracking(++$item_export, $time);
            }
        }
    }
    $xml_output .= '</entity_profile>' . "\n";
    ets_cache_tracking($item_export);
    ets_cache_export('total_range_price', $auto_increment);
    if (!$auto_increment)
        return $auto_increment;
    return $xml_output;
}

function ets_oneclicktomigrate_export_deliveries()
{
    global $wpdb;
    $methods = $wpdb->get_results("SELECT * FROM {$wpdb->prefix}woocommerce_shipping_zone_methods z WHERE is_enabled=1 GROUP BY z.zone_id, z.method_id");

    $item_export = ets_get_cache_tracking();
    ets_cache_export('export_table', 'delivery');
    $time = time();

    $xml_output = '<?xml version="1.0" encoding="UTF-8"?>' . "\n";
    $xml_output .= '<entity_profile>' . "\n";
    $auto_increment = 0;
    if ($methods) {
        foreach ($methods as $method) {
            if ($method->method_id != 'free_shipping') {
                $auto_increment++;
                $shipping = WC_Shipping_Zones::get_shipping_method($method->instance_id);
                $id_carrier = ets_oneclicktomigrate_get_id_carrier($method->method_id);
                $xml_output .= '<delivery>' . "\n";
                $xml_output .= '<id_delivery><![CDATA[' . $auto_increment . ']]></id_delivery>' . "\n";
                $xml_output .= '<id_carrier><![CDATA[' . $id_carrier . ']]></id_carrier>' . "\n";
                $xml_output .= '<id_range_price><![CDATA[' . $id_carrier . ']]></id_range_price>' . "\n";
                $xml_output .= '<id_range_weight><![CDATA[0]]></id_range_weight>' . "\n";
                $xml_output .= '<id_zone><![CDATA[' . (int)($method->zone_id + 1) . ']]></id_zone>' . "\n";
                $xml_output .= '<price><![CDATA[' . (float)$shipping->cost . ']]></price>' . "\n";
                $xml_output .= '</delivery>' . "\n";
                ets_cache_tracking(++$item_export, $time);
            }
        }
    }
    $shipping_class = new WC_Shipping();
    $id_carrier = 0;
    if (($shipping_methods = $shipping_class->get_shipping_methods())) {
        foreach ($shipping_methods as $shipping) {
            $id_carrier++;
            if ($shipping->id != 'free_shipping') {
                $auto_increment++;
                $xml_output .= '<delivery>' . "\n";
                $xml_output .= '<id_delivery><![CDATA[' . $auto_increment . ']]></id_delivery>' . "\n";
                $xml_output .= '<id_carrier><![CDATA[' . $id_carrier . ']]></id_carrier>' . "\n";
                $xml_output .= '<id_range_price><![CDATA[' . $id_carrier . ']]></id_range_price>' . "\n";
                $xml_output .= '<id_range_weight><![CDATA[0]]></id_range_weight>' . "\n";
                $xml_output .= '<id_zone><![CDATA[1]]></id_zone>' . "\n";
                $xml_output .= '<price><![CDATA[' . (float)$shipping->cost . ']]></price>' . "\n";
                $xml_output .= '</delivery>' . "\n";
                ets_cache_tracking(++$item_export, $time);
            }
        }
    }
    $xml_output .= '</entity_profile>' . "\n";
    ets_cache_tracking($item_export);
    ets_cache_export('total_delivery', $auto_increment);
    if (!$auto_increment)
        return false;
    return $xml_output;
}

//cache order.
function ets_cache_orders($dataCached, $objectCached)
{
    if (!@is_dir(($cacheFile = ETS_WP_DATA_XML . 'cache/')))
        @mkdir($cacheFile, 0755);

    if (@file_exists($cacheFile . $objectCached . '.json') && $dataCached) {
        $dataCached = array_merge((array)json_decode(@file_get_contents($cacheFile . $objectCached . '.json')), $dataCached);
    }
    if ($dataCached) {
        @file_put_contents($cacheFile . $objectCached . '.json', json_encode($dataCached), LOCK_EX);
    }
    unset($cacheFile);
}

function ets_get_cache_orders($objectCached)
{
    if (@file_exists(($cacheFile = ETS_WP_DATA_XML . 'cache/' . $objectCached . '.json')))
        return (array)json_decode(@file_get_contents($cacheFile));
    return array();
}

//end cache order.
function ets_oneclicktomigrate_get_orders($args = array())
{
    $arguments = array(
        'limit' => -1,
        'orderby' => 'date_created',
        'order' => 'ASC',
        'type' => 'shop_order',
        'return' => 'ids',
    );
    if ($args) {
        foreach ($args as $key => $arg) {
            $arguments[$key] = $arg;
        }
    }
    $orders = wc_get_orders($arguments);
    return $orders;
}

function ets_oneclicktomigrate_export_customer_group($customers, $paged)
{
    $item_export = ets_get_cache_tracking();
    $time = time();
    $xml_output = '<?xml version="1.0" encoding="UTF-8"?>' . "\n";
    $xml_output .= '<entity_profile>' . "\n";
    if ($customers) {
        foreach ($customers as $customer) {
            $xml_output .= '<customer_group>' . "\n";
            $xml_output .= '<id_customer><![CDATA[' . (int)$customer['id_customer'] . ']]></id_customer>' . "\n";
            $xml_output .= '<id_group><![CDATA[1]]></id_group>' . "\n";
            $xml_output .= '</customer_group>' . "\n";
            ets_cache_tracking(++$item_export, $time);
        }
    }
    $xml_output .= '</entity_profile>' . "\n";
    ets_cache_tracking($item_export);
    if (!@file_exists(($xmlFile = ETS_WP_DATA_XML . 'CustomerGroup_' . $paged . '.xml'))) {
        @file_put_contents($xmlFile, ets_is_sanitizeXML($xml_output), LOCK_EX);
    }
}

function ets_oneclicktomigrate_customer_validate($customer)
{
    if (!$customer)
        return $customer;
    if (!(isset($customer['firstname'])) || !$customer['firstname']) {
        $customer['firstname'] = isset($customer['lastname']) && $customer['lastname'] ? $customer['lastname'] : 'Name';
    }
    if (!(isset($customer['lastname'])) || !$customer['lastname']) {
        $customer['lastname'] = $customer['lastname'];
    }
    if (!(isset($customer['email'])) || !$customer['email']) {
        $customer['email'] = 'email_' . $customer['id_customer'] . '@export.com';
    }
    if (!(isset($customer['passwd'])) || !$customer['passwd']) {
        $customer['passwd'] = md5(time());
    }
    return $customer;
}

function ets_oneclicktomigrate_export_customer($args = array())
{
    $paged = -1;
    if (isset($args['paged']))
        $paged = (int)$args['paged'];
    $orders = ets_oneclicktomigrate_get_orders($args);
    if (!$orders) {
        ets_cache_export('customer', 1);
        ets_return_json(array('export' => 'Customer-end.xml'));
    }
    ets_cache_orders($orders, 'orders' . $paged);
    $ids_customer = ets_get_cache_orders('ids_customer');

    $item_export = ets_get_cache_tracking();
    ets_cache_export('export_table', 'customer');
    $time = time();

    $xml_output = '<?xml version="1.0" encoding="UTF-8"?>' . "\n";
    $xml_output .= '<entity_profile>' . "\n";
    $auto_increment = ($ikCached = ets_get_cache_export('total_customer')) ? (int)$ikCached : 0;
    $customers = array();
    foreach ($orders as $id_order) {
        $order = wc_get_order($id_order);
        $data_order = false;
        if (method_exists($order, 'get_data'))
            $data_order = $order->get_data();
        if (!$data_order) {
            $data_order['customer_id'] = $order->get_user_id();
            $data_order['billing'] = $order->get_address('billing');
            $data_order['date_created'] = $order->order_date;
            $data_order['date_modified'] = $order->modified_date;
        }
        if ($data_order) {
            $customer_id = isset($data_order['customer_id']) ? (int)$data_order['customer_id'] : 0;
            if ($customer_id) {
                if (!ets_oneclicktomigrate_get_id_customer($ids_customer, $customer_id)) {
                    $auto_increment++;
                    $ids_customer[$customer_id] = $auto_increment;
                    global $wpdb;
                    $result = $wpdb->get_results("SELECT * FROM {$wpdb->prefix}users u WHERE ID='" . (int)$customer_id . "'");
                    $customer = array(
                        'id_customer' => $auto_increment,
                        'id_gender' => 1,
                        'id_default_group' => 1,
                        'passwd' => isset($result[0]) && $result[0] ? $result[0]->user_pass : md5(time()),
                        'firstname' => isset($data_order['billing']['first_name']) ? $data_order['billing']['first_name'] : '',
                        'lastname' => isset($data_order['billing']['last_name']) ? $data_order['billing']['last_name'] : '',
                        'email' => isset($result[0]) && $result[0] ? $result[0]->user_email : $data_order['billing']['email'],
                        'last_passwd_gen' => isset($result[0]) && $result[0] ? $result[0]->user_registered : '0000-00-00 00:00:00',
                        'birthday' => '0000-00-00',
                        'newsletter' => 1,
                        'ip_registration_newsletter' => '',
                        'newsletter_date_add' => date('Y-m-d h:i:s', time()),
                        'optin' => 1,
                        'secure_key' => '',
                        'note' => '',
                        'active' => 1,
                        'is_guest' => 0,
                        'deleted' => 0,
                        'date_add' => isset($result[0]) && $result[0] ? $result[0]->user_registered : date_format(date_create($data_order['date_created']->__toString()), 'Y-m-d h:i:s'),
                        'date_upd' => isset($result[0]) && $result[0] ? $result[0]->user_registered : date_format(date_create($data_order['date_created']->__toString()), 'Y-m-d h:i:s'),
                    );
                    $customers[] = ets_oneclicktomigrate_customer_validate($customer);
                }
            } else {
                $auto_increment++;
                $ids_customer[$id_order . '-0'] = $auto_increment;
                $customer = array(
                    'id_customer' => $auto_increment,
                    'id_gender' => 1,
                    'id_default_group' => 1,
                    'passwd' => md5(time()),
                    'firstname' => isset($data_order['billing']['first_name']) ? $data_order['billing']['first_name'] : '',
                    'lastname' => isset($data_order['billing']['last_name']) ? $data_order['billing']['last_name'] : '',
                    'email' => isset($data_order['billing']['email']) ? $data_order['billing']['email'] : '',
                    'last_passwd_gen' => '0000-00-00 00:00:00',
                    'birthday' => '0000-00-00',
                    'newsletter' => 1,
                    'ip_registration_newsletter' => '',
                    'newsletter_date_add' => date('Y-m-d h:i:s', time()),
                    'optin' => 1,
                    'secure_key' => '',
                    'note' => '',
                    'active' => 1,
                    'is_guest' => 1,
                    'deleted' => 0,
                    'date_add' => date_format(date_create((is_object($data_order['date_created']) ? $data_order['date_created']->__toString() : $data_order['date_created'])), 'Y-m-d h:i:s'),
                    'date_upd' => date_format(date_create((is_object($data_order['date_modified']) ? $data_order['date_modified']->__toString() : $data_order['date_modified'])), 'Y-m-d h:i:s'),
                );
                $customers[] = ets_oneclicktomigrate_customer_validate($customer);
            }
            if (isset($customer) && $customer) {
                $xml_output .= '<customer>' . "\n";
                foreach ($customer as $key => $value) {
                    $xml_output .= '<' . $key . '><![CDATA[' . $value . ']]></' . $key . '>' . "\n";
                }
                $xml_output .= '</customer>' . "\n";
                ets_cache_tracking(++$item_export, $time);
                unset($customer);
            }
        }
    }
    $xml_output .= '</entity_profile>' . "\n";
    ets_cache_tracking($item_export);
    if ($ids_customer)
        ets_cache_orders($ids_customer, 'ids_customer');
    if ($customers)
        ets_oneclicktomigrate_export_customer_group($customers, $paged);
    ets_cache_exports(array('total_customer' => $auto_increment, 'total_customer_group' => $auto_increment, 'customer_paged' => ($paged < 0 ? 0 : $paged)));
    if ($auto_increment <= $ikCached)
        return false;
    return $xml_output;
}

function cleanNonUnicodeSupport($pattern)
{
    if (!defined('PREG_BAD_UTF8_OFFSET')) {
        return $pattern;
    }
    return preg_replace('/\\\[px]\{[a-z]{1,2}\}|(\/[a-z]*)u([a-z]*)$/i', '$1$2', $pattern);
}

function ets_oneclicktomigrate_is_address($address)
{
    return empty($address) || preg_match(cleanNonUnicodeSupport('/^[^!<>?=+@{}_$%]*$/u'), $address);
}

function ets_oneclicktomigrate_address_validate($address)
{
    if (!$address)
        return $address;
    if (!(isset($address['firstname'])) || !$address['firstname']) {
        $address['firstname'] = isset($address['lastname']) && $address['lastname'] ? $address['lastname'] : 'Name';
    }
    if (!(isset($address['lastname'])) || !$address['lastname']) {
        $address['lastname'] = $address['firstname'];
    }
    if (!(isset($address['address1'])) || !$address['address1'] || !ets_oneclicktomigrate_is_address($address['address1'])) {
        $address['address1'] = 'address invalid';
    }
    if (!(isset($address['city'])) || !$address['city']) {
        $address['city'] = 'City';
    }
    return $address;
}

function ets_oneclicktomigrate_get_id_address_exists($ids_address, $address, $type)
{
    if (!$ids_address || !$address)
        return false;
    foreach ($ids_address as $key => $order_address) {
        if (strpos($key, $type . '-') !== -1) {
            $isChecked = true;
            foreach ($order_address as $ikey => $value) {
                if (isset($address[$ikey]) && $value != $address[$ikey]) {
                    $isChecked = false;
                    break;
                }
            }
            return $isChecked;
        }
    }
    return false;
}

function ets_oneclicktomigrate_compare_address($billing, $shipping, $address_format)
{
    if (!$billing || !$shipping)
        return false;
    if (!$address_format) {
        $address_format = "first_name|last_name|company|address_1|address_2|city|state|postcode|country";
    }
    $address_formated = explode('|', $address_format);
    foreach ($address_formated as $key) {
        if (!(isset($shipping[$key])) || !(isset($billing[$key])) || (trim($shipping[$key]) != trim($billing[$key]))) {
            return false;
        }
    }
    return true;
}

function ets_oneclicktomigrate_format_address(&$address, $address_format)
{
    if (!$address)
        return $address;
    if (($address_formated = explode('|', $address_format))) {
        foreach ($address_formated as $key) {
            if (!(isset($address[$key])))
                $address[$key] = null;
        }
    }
    return $address;
}

function ets_oneclicktomigrate_get_id_customer($ids_customer, $customer_id)
{
    if ($ids_customer) {
        foreach ($ids_customer as $key => $value) {
            if ($key == $customer_id)
                return $value;
        }
    }
    return 0;
}

function ets_oneclicktomigrate_address_empty($address)
{
    if (!$address)
        return true;
    if ($address)
        foreach ($address as $value)
            if ($value)
                return false;
    return true;
}

function ets_oneclicktomigrate_export_address($args = array())
{
    $paged = -1;
    if (isset($args['paged']))
        $paged = (int)$args['paged'];
    $orders = ets_get_cache_orders('orders' . $paged);
    if (!$orders)
        $orders = ets_oneclicktomigrate_get_orders($args);
    if (!$orders) {
        ets_cache_export('address', 1);
        ets_return_json(array('export' => 'Address-end.xml'));
    }
    $ids_address = ets_get_cache_orders('ids_address');
    $ids_customer = ets_get_cache_orders('ids_customer');

    $item_export = ets_get_cache_tracking();
    ets_cache_export('export_table', 'address');
    $time = time();

    $xml_output = '<?xml version="1.0" encoding="UTF-8"?>' . "\n";
    $xml_output .= '<entity_profile>' . "\n";
    $auto_increment = ($ikCached = (int)ets_get_cache_export('total_address')) ? $ikCached : 0;
    $address_format = "first_name|last_name|company|address_1|address_2|city|state|postcode|country";
    foreach ($orders as $id_order) {
        $addresses = array();
        $order = wc_get_order($id_order);
        $data_order = false;
        if (method_exists($order, 'get_data'))
            $data_order = $order->get_data();
        if (!$data_order) {
            $data_order['customer_id'] = $order->get_user_id();
            $data_order['billing'] = $order->get_address('billing');
            $data_order['shipping'] = $order->get_address('shipping');
            $data_order['date_created'] = $order->order_date;
            $data_order['date_modified'] = $order->modified_date;
        }
        if ($data_order) {
            $customer_id = (int)ets_oneclicktomigrate_get_id_customer($ids_customer, (isset($data_order['customer_id']) && $data_order['customer_id'] ? $data_order['customer_id'] : $id_order . '-0'));
            if (!ets_oneclicktomigrate_address_empty($data_order['billing']) && !ets_oneclicktomigrate_address_empty($data_order['shipping']) && ets_oneclicktomigrate_compare_address($data_order['billing'], $data_order['shipping'], $address_format)) {
                $auto_increment++;
                ets_oneclicktomigrate_format_address($data_order['billing'], $address_format);
                $address_shipping = array(
                    'id_address' => $auto_increment,
                    'id_customer' => $customer_id,
                    'id_manufacturer' => 0,
                    'id_supplier' => 0,
                    'id_warehouse' => 0,
                    'id_country' => (int)ets_oneclicktomigrate_get_id_country($data_order['billing']['country']),
                    'id_state' => (int)ets_oneclicktomigrate_get_id_state($data_order['billing']['state'], $data_order['billing']['country']),
                    'alias' => 'address-' . $auto_increment,
                    'company' => $data_order['billing']['company'],
                    'firstname' => $data_order['billing']['first_name'],
                    'lastname' => $data_order['billing']['last_name'],
                    'vat_number' => '',
                    'address1' => $data_order['billing']['address_1'],
                    'address2' => $data_order['billing']['address_2'],
                    'postcode' => $data_order['billing']['postcode'],
                    'city' => $data_order['billing']['city'],
                    'other' => '',
                    'phone' => $data_order['billing']['phone'],
                    'phone_mobile' => '',
                    'dni' => '',
                    'deleted' => 0,
                    'date_add' => date_format(date_create((is_object($data_order['date_created']) ? $data_order['date_created']->__toString() : $data_order['date_created'])), 'Y-m-d h:i:s'),
                    'date_upd' => date_format(date_create((is_object($data_order['date_modified']) ? $data_order['date_modified']->__toString() : $data_order['date_modified'])), 'Y-m-d h:i:s'),
                );
                if (!ets_oneclicktomigrate_get_id_address_exists($ids_address, $address_shipping, 'shipping-')) {
                    $data_order['shipping']['id_address'] = $auto_increment;
                    $ids_address['shipping-' . $id_order] = $data_order['shipping'];
                    $addresses[] = ets_oneclicktomigrate_address_validate($address_shipping);
                } else
                    $auto_increment--;
            } else {
                if (!ets_oneclicktomigrate_address_empty($data_order['billing'])) {
                    $auto_increment++;
                    ets_oneclicktomigrate_format_address($data_order['billing'], $address_format);
                    $address_billing = array(
                        'id_address' => $auto_increment,
                        'id_customer' => $customer_id,
                        'id_manufacturer' => 0,
                        'id_supplier' => 0,
                        'id_warehouse' => 0,
                        'id_country' => (int)ets_oneclicktomigrate_get_id_country($data_order['billing']['country']),
                        'id_state' => (int)ets_oneclicktomigrate_get_id_state($data_order['billing']['state'], $data_order['billing']['country']),
                        'alias' => 'address-' . $auto_increment,
                        'company' => $data_order['billing']['company'],
                        'lastname' => $data_order['billing']['first_name'],
                        'firstname' => $data_order['billing']['last_name'],
                        'vat_number' => '',
                        'address1' => $data_order['billing']['address_1'],
                        'address2' => $data_order['billing']['address_2'],
                        'postcode' => $data_order['billing']['postcode'],
                        'city' => $data_order['billing']['city'],
                        'other' => '',
                        'phone' => $data_order['billing']['phone'],
                        'phone_mobile' => '',
                        'dni' => '',
                        'deleted' => 0,
                        'date_add' => date_format(date_create((is_object($data_order['date_created']) ? $data_order['date_created']->__toString() : $data_order['date_created'])), 'Y-m-d h:i:s'),
                        'date_upd' => date_format(date_create((is_object($data_order['date_modified']) ? $data_order['date_modified']->__toString() : $data_order['date_modified'])), 'Y-m-d h:i:s'),
                    );
                    if (!ets_oneclicktomigrate_get_id_address_exists($ids_address, $address_billing, 'billing-')) {
                        $data_order['billing']['id_address'] = $auto_increment;
                        $ids_address['billing-' . $id_order] = $data_order['billing'];
                        $addresses[] = ets_oneclicktomigrate_address_validate($address_billing);
                    } else
                        $auto_increment--;
                }
                if (!ets_oneclicktomigrate_address_empty($data_order['shipping'])) {
                    $auto_increment++;
                    ets_oneclicktomigrate_format_address($data_order['shipping'], $address_format);
                    $address_shipping = array(
                        'id_address' => $auto_increment,
                        'id_customer' => $customer_id,
                        'id_manufacturer' => 0,
                        'id_supplier' => 0,
                        'id_warehouse' => 0,
                        'id_country' => (int)ets_oneclicktomigrate_get_id_country($data_order['shipping']['country']),
                        'id_state' => (int)ets_oneclicktomigrate_get_id_state($data_order['shipping']['state'], $data_order['shipping']['country']),
                        'alias' => 'address-' . $auto_increment,
                        'company' => $data_order['shipping']['company'],
                        'lastname' => $data_order['shipping']['first_name'],
                        'firstname' => $data_order['shipping']['last_name'],
                        'vat_number' => '',
                        'address1' => $data_order['shipping']['address_1'],
                        'address2' => $data_order['shipping']['address_2'],
                        'postcode' => $data_order['shipping']['postcode'],
                        'city' => $data_order['shipping']['city'],
                        'other' => '',
                        'phone' => $data_order['billing']['phone'],
                        'phone_mobile' => '',
                        'dni' => '',
                        'deleted' => 0,
                        'date_add' => date_format(date_create((is_object($data_order['date_created']) ? $data_order['date_created']->__toString() : $data_order['date_created'])), 'Y-m-d h:i:s'),
                        'date_upd' => date_format(date_create((is_object($data_order['date_modified']) ? $data_order['date_modified']->__toString() : $data_order['date_modified'])), 'Y-m-d h:i:s'),
                    );
                    if (!ets_oneclicktomigrate_get_id_address_exists($ids_address, $address_shipping, 'shipping-')) {
                        $data_order['shipping']['id_address'] = $auto_increment;
                        $ids_address['shipping-' . $id_order] = $data_order['shipping'];
                        $addresses[] = ets_oneclicktomigrate_address_validate($address_shipping);
                    } else
                        $auto_increment--;
                }
            }
        }
        if ($addresses) {
            foreach ($addresses as $address) {
                $xml_output .= '<address>' . "\n";
                $xml_output .= '<id_address><![CDATA[' . (int)$address['id_address'] . ']]></id_address>' . "\n";
                $xml_output .= '<id_customer><![CDATA[' . (int)$address['id_customer'] . ']]></id_customer>' . "\n";
                $xml_output .= '<id_manufacturer><![CDATA[' . (int)$address['id_manufacturer'] . ']]></id_manufacturer>' . "\n";
                $xml_output .= '<woocommerce><![CDATA[1]]></woocommerce>' . "\n";
                $xml_output .= '<id_supplier><![CDATA[' . (int)$address['id_supplier'] . ']]></id_supplier>' . "\n";
                $xml_output .= '<id_warehouse><![CDATA[' . (int)$address['id_warehouse'] . ']]></id_warehouse>' . "\n";
                $xml_output .= '<id_country><![CDATA[' . (int)$address['id_country'] . ']]></id_country>' . "\n";
                $xml_output .= '<id_state><![CDATA[' . (int)$address['id_state'] . ']]></id_state>' . "\n";
                $xml_output .= '<alias><![CDATA[' . $address['alias'] . ']]></alias>' . "\n";
                $xml_output .= '<company><![CDATA[' . $address['company'] . ']]></company>' . "\n";
                $xml_output .= '<lastname><![CDATA[' . $address['lastname'] . ']]></lastname>' . "\n";
                $xml_output .= '<firstname><![CDATA[' . $address['firstname'] . ']]></firstname>' . "\n";
                $xml_output .= '<vat_number><![CDATA[' . $address['vat_number'] . ']]></vat_number>' . "\n";
                $xml_output .= '<address1><![CDATA[' . $address['address1'] . ']]></address1>' . "\n";
                $xml_output .= '<address2><![CDATA[' . $address['address2'] . ']]></address2>' . "\n";
                $xml_output .= '<postcode><![CDATA[' . $address['postcode'] . ']]></postcode>' . "\n";
                $xml_output .= '<city><![CDATA[' . $address['city'] . ']]></city>' . "\n";
                $xml_output .= '<other><![CDATA[' . $address['other'] . ']]></other>' . "\n";
                $xml_output .= '<phone><![CDATA[' . $address['phone'] . ']]></phone>' . "\n";
                $xml_output .= '<phone_mobile><![CDATA[' . $address['phone_mobile'] . ']]></phone_mobile>' . "\n";
                $xml_output .= '<dni><![CDATA[' . $address['dni'] . ']]></dni>' . "\n";
                $xml_output .= '<deleted><![CDATA[' . $address['deleted'] . ']]></deleted>' . "\n";
                $xml_output .= '<date_add><![CDATA[' . $address['date_add'] . ']]></date_add>' . "\n";
                $xml_output .= '<date_upd><![CDATA[' . $address['date_upd'] . ']]></date_upd>' . "\n";
                $xml_output .= '</address>' . "\n";
                ets_cache_tracking(++$item_export, $time);
            }
            unset($addresses);
        }
    }
    $xml_output .= '</entity_profile>' . "\n";
    ets_cache_tracking($item_export);
    if ($ids_address)
        ets_cache_orders($ids_address, 'ids_address');
    ets_cache_exports(array('total_address' => ($auto_increment - 1), 'address_paged' => ($paged < 0 ? 0 : $paged)));
    if ($auto_increment <= $ikCached)
        return false;
    return $xml_output;
}

function ets_oneclicktomigrate_get_id_carrier($id_shipping_method)
{
    $shipping_class = new WC_Shipping();
    $shipping_methods = $shipping_class->get_shipping_methods();
    if ($shipping_methods) {
        $auto_increment = 0;
        foreach ($shipping_methods as $key => $shipping) {
            $auto_increment++;
            if ($id_shipping_method == $key) {
                return $auto_increment;
            }
        }
    }
    return 0;
}

function ets_oneclicktomigrate_export_carts($args = array())
{
    $paged = -1;
    if (isset($args['paged']))
        $paged = (int)$args['paged'];
    $orders = ets_get_cache_orders('orders' . $paged);
    if (!$orders)
        $orders = ets_oneclicktomigrate_get_orders($args);
    if (!$orders) {
        ets_cache_export('cart', 1);
        ets_return_json(array('export' => 'Cart-end.xml'));
    }
    $ids_address = ets_get_cache_orders('ids_address');
    $ids_carrier = ets_get_cache_orders('ids_carrier');
    $ids_customer = ets_get_cache_orders('ids_customer');

    $item_export = ets_get_cache_tracking();
    ets_cache_export('export_table', 'cart');
    $time = time();

    $xml_output = '<?xml version="1.0" encoding="UTF-8"?>' . "\n";
    $xml_output .= '<entity_profile>' . "\n";
    $auto_increment = ($ikCached = ets_get_cache_export('total_cart')) ? (int)$ikCached : 0;
    foreach ($orders as $id) {
        $order = wc_get_order($id);
        //getCarrier.
        $shipping_method_id = 0;
        if (($shipping_methods = $order->get_shipping_methods())) {
            foreach ($shipping_methods as $shipping_method) {
                if ((property_exists($shipping_method, 'get_method_id') && ($shipping_method_id = $shipping_method->get_method_id())) || (property_exists($shipping_method, 'method_id') && ($shipping_method_id = $shipping_method->method_id))) {
                    break;
                }
            }
        }
        $id_carrier = $shipping_method_id ? ets_oneclicktomigrate_get_id_carrier($shipping_method_id) : 2;
        $ids_carrier[$id] = $id_carrier;
        //getCart.
        $data_order = false;
        if (method_exists($order, 'get_data'))
            $data_order = $order->get_data();
        if (!$data_order) {
            $data_order['customer_id'] = $order->get_user_id();
            $data_order['currency'] = $order->get_order_currency();
            $data_order['date_created'] = $order->order_date;
            $data_order['date_modified'] = $order->modified_date;
        }
        if ($data_order) {
            $auto_increment++;
            $id_customer = (int)ets_oneclicktomigrate_get_id_customer($ids_customer, (isset($data_order['customer_id']) && $data_order['customer_id'] ? $data_order['customer_id'] : $id . '-0'));
            $billing_address = isset($ids_address['billing-' . $id]) ? $ids_address['billing-' . $id] : false;
            if (isset($ids_address['shipping-' . $id]))
                $shipping_address = $ids_address['shipping-' . $id];
            else
                $shipping_address = $billing_address;

            $id_address_delivery = 0;
            if (is_object($shipping_address) && isset($shipping_address->id_address))
                $id_address_delivery = $shipping_address->id_address;
            elseif (is_array($shipping_address) && isset($shipping_address['id_address']))
                $id_address_delivery = $shipping_address['id_address'];

            $id_address_invoice = 0;
            if (is_object($billing_address) && isset($billing_address->id_address))
                $id_address_invoice = $billing_address->id_address;
            elseif (is_array($billing_address) && isset($billing_address['id_address']))
                $id_address_invoice = $billing_address['id_address'];

            $cart = array(
                'id_cart' => $auto_increment,
                'id_carrier' => $id_carrier,
                'id_lang' => 1,
                'id_address_delivery' => $id_address_delivery,
                'id_address_invoice' => $id_address_invoice,
                'id_currency' => ets_oneclicktomigrate_get_id_currency($data_order['currency']),
                'id_customer' => $id_customer,
                'id_guest' => 0,
                'secure_key' => -1,
                'recyclable' => 1,
                'gift' => 0,
                'gift_message' => '',
                'date_add' => date_format(date_create((is_object($data_order['date_created']) ? $data_order['date_created']->__toString() : $data_order['date_created'])), 'Y-m-d h:i:s'),
                'date_upd' => date_format(date_create((is_object($data_order['date_modified']) ? $data_order['date_modified']->__toString() : $data_order['date_modified'])), 'Y-m-d h:i:s'),
            );
            $xml_output .= '<cart>' . "\n";
            foreach ($cart as $key => $value) {
                $xml_output .= '<' . $key . '><![CDATA[' . $value . ']]></' . $key . '>' . "\n";
            }
            $xml_output .= '</cart>' . "\n";
            ets_cache_tracking(++$item_export, $time);
        }
    }
    $xml_output .= '</entity_profile>' . "\n";
    ets_cache_tracking($item_export);
    ets_cache_exports(array('total_cart' => $auto_increment, 'cart_paged' => ($paged < 0 ? 0 : $paged)));
    if ($ids_carrier)
        ets_cache_orders($ids_carrier, 'ids_carrier');
    if ($auto_increment <= $ikCached)
        return false;
    return $xml_output;
}

function ets_oneclicktomigrate_order_id_carrier($ids_carrier, $id_order)
{
    if ($ids_carrier)
        foreach ($ids_carrier as $key => $value) {
            if ($id_order == $key)
                return $value;
        }
    return 0;
}

function ets_oneclicktomigrate_export_orders($args = array())
{
    $paged = -1;
    if (isset($args['paged']))
        $paged = (int)$args['paged'];
    $orders = ets_get_cache_orders('orders' . $paged);
    if (!$orders)
        $orders = ets_oneclicktomigrate_get_orders($args);
    if (!$orders) {
        ets_cache_export('order', 1);
        ets_return_json(array('export' => 'Order-end.xml'));
    }
    $ids_address = ets_get_cache_orders('ids_address');
    $ids_carrier = ets_get_cache_orders('ids_carrier');
    $ids_customer = ets_get_cache_orders('ids_customer');
    $auto_increment = ($ikCached = ets_get_cache_export('total_order')) ? (int)$ikCached : 0;

    $item_export = ets_get_cache_tracking();
    ets_cache_export('export_table', 'order');
    $time = time();

    $xml_output = '<?xml version="1.0" encoding="UTF-8"?>' . "\n";
    $xml_output .= '<entity_profile>' . "\n";
    foreach ($orders as $id) {
        $wc_order = wc_get_order($id);
        $data_order = array();
        if (method_exists($wc_order, 'get_data'))
            $data_order = $wc_order->get_data();
        if (!$data_order) {
            $data_order['customer_id'] = $wc_order->get_user_id();
            $data_order['currency'] = $wc_order->get_order_currency();
            $data_order['status'] = $wc_order->get_status();
            $data_order['payment_method_title'] = $wc_order->payment_method_title;
            $data_order['payment_method'] = $wc_order->payment_method;
            $data_order['date_created'] = $wc_order->order_date;
            $data_order['date_modified'] = $wc_order->modified_date;
            $data_order['discount_total'] = wc_format_decimal($wc_order->get_total_discount());
            $data_order['discount_tax'] = wc_format_decimal($wc_order->cart_discount_tax);
            $data_order['shipping_total'] = wc_format_decimal($wc_order->get_total_shipping());
            $data_order['shipping_tax'] = wc_format_decimal($wc_order->get_shipping_tax());
            $data_order['cart_tax'] = wc_format_decimal($wc_order->get_cart_tax());
            $data_order['total'] = wc_format_decimal($wc_order->get_total());
            $data_order['total_tax'] = wc_format_decimal($wc_order->get_total_tax());
        }
        if ($data_order) {
            $auto_increment++;
            $id_customer = (int)ets_oneclicktomigrate_get_id_customer($ids_customer, (isset($data_order['customer_id']) && $data_order['customer_id'] ? $data_order['customer_id'] : $id . '-0'));

            $total_products = ($data_order['total'] - $data_order['total_tax'] - $data_order['shipping_total'] + $data_order['discount_total']);
            $billing_address = isset($ids_address['billing-' . $id]) ? $ids_address['billing-' . $id] : false;
            if (isset($ids_address['shipping-' . $id]))
                $shipping_address = $ids_address['shipping-' . $id];
            else
                $shipping_address = $billing_address;

            $id_address_delivery = 0;
            if (is_object($shipping_address) && isset($shipping_address->id_address))
                $id_address_delivery = $shipping_address->id_address;
            elseif (is_array($shipping_address) && isset($shipping_address['id_address']))
                $id_address_delivery = $shipping_address['id_address'];

            $id_address_invoice = 0;
            if (is_object($billing_address) && isset($billing_address->id_address))
                $id_address_invoice = $billing_address->id_address;
            elseif (is_array($billing_address) && isset($billing_address['id_address']))
                $id_address_invoice = $billing_address['id_address'];

            $order = array(
                'id_order' => $id,
                'id_carrier' => (int)ets_oneclicktomigrate_order_id_carrier($ids_carrier, $id),
                'id_lang' => 1,
                'id_customer' => $id_customer,
                'id_cart' => $auto_increment,
                'reference' => $data_order['id'],
                'current_state' => ets_oneclicktomigrate_get_id_status($data_order['status']),
                'id_currency' => ets_oneclicktomigrate_get_id_currency($data_order['currency']),
                'id_address_delivery' => $id_address_delivery,
                'id_address_invoice' => $id_address_invoice,
                'secure_key' => md5($id_customer),
                'payment' => isset($data_order['payment_method_title']) ? $data_order['payment_method_title'] : '',
                'conversion_rate' => 1,
                'module' => isset($data_order['payment_method']) ? $data_order['payment_method'] : '',
                'recyclable' => 0,
                'gift' => 0,
                'gift_message' => 0,
                'shipping_number' => '',
                'total_discounts' => $data_order['discount_total'],
                'total_discounts_tax_incl' => $data_order['discount_total'] + $data_order['discount_tax'],
                'total_discounts_tax_excl' => $data_order['discount_total'],
                'total_shipping' => $data_order['shipping_total'],
                'total_shipping_tax_incl' => $data_order['shipping_total'] + $data_order['shipping_tax'],
                'total_shipping_tax_excl' => $data_order['shipping_total'],
                'total_paid' => $data_order['total'],
                'total_paid_tax_incl' => $data_order['total'],
                'total_paid_tax_excl' => $data_order['total'] - $data_order['total_tax'],
                'total_paid_real' => $data_order['total'],
                'total_products' => $total_products,
                'total_products_wt' => $data_order['total'] - $data_order['shipping_total'] - $data_order['shipping_tax'] + $data_order['discount_total'] + $data_order['discount_tax'],
                'valid' => 0,
                'date_add' => date_format(date_create((is_object($data_order['date_created']) ? $data_order['date_created']->__toString() : $data_order['date_created'])), 'Y-m-d h:i:s'),
                'date_upd' => date_format(date_create((is_object($data_order['date_modified']) ? $data_order['date_modified']->__toString() : $data_order['date_modified'])), 'Y-m-d h:i:s'),
            );
            $xml_output .= '<orders>' . "\n";
            foreach ($order as $key => $value) {
                $xml_output .= '<' . $key . '><![CDATA[' . $value . ']]></' . $key . '>' . "\n";
            }
            $xml_output .= '</orders>' . "\n";
            ets_cache_tracking(++$item_export, $time);
            unset($order);
        }
    }
    $xml_output .= '</entity_profile>' . "\n";
    ets_cache_tracking($item_export);
    ets_cache_exports(array('total_order' => $auto_increment, 'order_paged' => ($paged < 0 ? 0 : $paged)));
    if ($auto_increment <= $ikCached)
        return false;
    return $xml_output;
}

function ets_oneclicktomigrate_export_order_detail($args = array())
{
    $paged = -1;
    if (isset($args['paged']))
        $paged = (int)$args['paged'];
    $orders = ets_get_cache_orders('orders' . $paged);
    if (!$orders)
        $orders = ets_oneclicktomigrate_get_orders($args);
    if (!$orders) {
        ets_cache_export('order_detail', 1);
        ets_return_json(array('export' => 'OrderDetail-end.xml'));
    }
    $item_export = ets_get_cache_tracking();
    ets_cache_export('export_table', 'order_detail');
    $time = time();

    $xml_output = '<?xml version="1.0" encoding="UTF-8"?>' . "\n";
    $xml_output .= '<entity_profile>' . "\n";
    $auto_increment = ($ikCached = ets_get_cache_export('total_order_detail')) ? (int)$ikCached : 0;
    foreach ($orders as $id) {
        $order = wc_get_order($id);
        $data_order = array();
        if (method_exists($order, 'get_data'))
            $data_order = $order->get_data();
        if (!$data_order) {
            $data_order['line_items'] = array();
            // Add line items.
            foreach ($order->get_items() as $item_id => $item) {
                $product = $order->get_product_from_item($item);
                $product_id = 0;
                $variation_id = 0;
                $product_sku = null;
                if (is_object($product)) {
                    $product_id = $product->get_id();
                    $variation_id = $product->variation_id;
                    $product_sku = $product->get_sku();
                }
                $line_item = array(
                    'id' => $item_id,
                    'name' => $item['name'],
                    'sku' => $product_sku,
                    'product_id' => (int)$product_id,
                    'variation_id' => (int)$variation_id,
                    'quantity' => wc_stock_amount($item['qty']),
                    'tax_class' => !empty($item['tax_class']) ? $item['tax_class'] : '',
                    'price' => wc_format_decimal($order->get_item_total($item, false, false)),
                    'subtotal' => wc_format_decimal($order->get_line_subtotal($item, false, false)),
                    'subtotal_tax' => wc_format_decimal($item['line_subtotal_tax']),
                    'total' => wc_format_decimal($order->get_line_total($item, false, false)),
                    'total_tax' => wc_format_decimal($item['line_tax']),
                );
                $data_order['line_items'][] = $line_item;
            }
        }
        if ($data_order) {
            $line_items = isset($data_order['line_items']) ? $data_order['line_items'] : false;
            if ($line_items) {
                foreach ($line_items as $line_item) {
                    $auto_increment++;
                    if (is_object($line_item) && method_exists($line_item, 'get_data'))
                        $product_data = $line_item->get_data();
                    else
                        $product_data = $line_item;
                    $orderDetail = array(
                        'id_order_detail' => $auto_increment,
                        'id_order' => $id,
                        'product_id' => $product_data['product_id'],
                        'product_attribute_id' => 0,
                        'product_name' => $product_data['name'],
                        'product_quantity' => $product_data['quantity'],
                        'product_quantity_in_stock' => 0,
                        'product_quantity_refunded' => 0,
                        'product_quantity_return' => 0,
                        'product_quantity_reinjected' => 0,
                        'product_price' => (float)$product_data['total'] / (float)$product_data['quantity'],
                        'original_product_price' => (float)$product_data['total'] / (float)$product_data['quantity'],
                        'unit_price_tax_incl' => (float)$product_data['total'] / (float)$product_data['quantity'] + (float)$product_data['total_tax'] / (float)$product_data['quantity'],
                        'unit_price_tax_excl' => (float)$product_data['total'] / (float)$product_data['quantity'],
                        'total_price_tax_incl' => (float)$product_data['total'] + (float)$product_data['total_tax'],
                        'total_price_tax_excl' => (float)$product_data['total'],
                    );
                    $xml_output .= '<order_detail>' . "\n";
                    foreach ($orderDetail as $key => $value) {
                        $xml_output .= '<' . $key . '><![CDATA[' . $value . ']]></' . $key . '>' . "\n";
                    }
                    $xml_output .= '</order_detail>' . "\n";
                    ets_cache_tracking(++$item_export, $time);
                }
            }
        }
    }
    $xml_output .= '</entity_profile>' . "\n";
    ets_cache_tracking($item_export);
    ets_cache_exports(array('total_order_detail' => $auto_increment, 'od_paged' => ($paged < 0 ? 0 : $paged)));
    if ($auto_increment <= $ikCached)
        return false;
    return $xml_output;
}

function ets_oneclicktomigrate_export_order_history($args = array())
{
    $paged = -1;
    if (isset($args['paged']))
        $paged = (int)$args['paged'];
    $orders = ets_get_cache_orders('orders' . $paged);
    if (!$orders)
        $orders = ets_oneclicktomigrate_get_orders($args);
    if (!$orders) {
        ets_cache_export('order_history', 1);
        ets_return_json(array('export' => 'OrderHistory-end.xml'));
    }
    $item_export = ets_get_cache_tracking();
    ets_cache_export('export_table', 'order_history');
    $time = time();

    $xml_output = '<?xml version="1.0" encoding="UTF-8"?>' . "\n";
    $xml_output .= '<entity_profile>' . "\n";
    $auto_increment = ($ikCached = ets_get_cache_export('total_order_history')) ? (int)$ikCached : 0;
    foreach ($orders as $id) {
        $order = wc_get_order($id);
        $data_order = array();
        if (method_exists($order, 'get_data'))
            $data_order = $order->get_data();
        else {
            $data_order['status'] = $order->get_status();
            $data_order['date_created'] = $order->order_date;
        }
        if ($data_order) {
            $auto_increment++;
            $orderHistory = array(
                'id_order_history' => $auto_increment,
                'id_employee' => 0,
                'id_order' => $id,
                'id_order_state' => ets_oneclicktomigrate_get_id_status($data_order['status']),
                'date_add' => date_format(date_create((is_object($data_order['date_created']) ? $data_order['date_created']->__toString() : $data_order['date_created'])), 'Y-m-d h:i:s'),
            );
            $xml_output .= '<order_history>' . "\n";
            foreach ($orderHistory as $key => $value) {
                $xml_output .= '<' . $key . '><![CDATA[' . $value . ']]></' . $key . '>' . "\n";
            }
            $xml_output .= '</order_history>' . "\n";
            ets_cache_tracking(++$item_export, $time);
        }
    }
    $xml_output .= '</entity_profile>' . "\n";
    ets_cache_tracking($item_export);
    ets_cache_exports(array('total_order_history' => $auto_increment, 'oh_paged' => ($paged < 0 ? 0 : $paged)));
    if ($auto_increment <= $ikCached)
        return false;
    return $xml_output;
}

function ets_oneclicktomigrate_export_order_message($args = array())
{
    $paged = -1;
    if (isset($args['paged']))
        $paged = (int)$args['paged'];
    $orders = ets_get_cache_orders('orders' . $paged);
    if (!$orders)
        $orders = ets_oneclicktomigrate_get_orders($args);
    if (!$orders) {
        ets_cache_export('order_message', 1);
        ets_return_json(array('export' => 'Message-end.xml'));
    }
    $item_export = ets_get_cache_tracking();
    ets_cache_export('export_table', 'order_message');
    $time = time();

    $ids_customer = ets_get_cache_orders('ids_customer');
    $xml_output = '<?xml version="1.0" encoding="UTF-8"?>' . "\n";
    $xml_output .= '<entity_profile>' . "\n";
    $auto_increment = ($ikCached = ets_get_cache_export('total_order_message')) ? (int)$ikCached : 0;
    $id_cart = ($cachedId = ets_get_cache_export('cached_id_cart')) ? (int)$cachedId : 0;
    foreach ($orders as $id) {
        $order = wc_get_order($id);
        $order = wc_get_order($id);
        $data_order = array();
        if (method_exists($order, 'get_data'))
            $data_order = $order->get_data();
        else {
            $data_order['customer_id'] = $order->get_user_id();
            $data_order['customer_note'] = $order->get_customer_order_notes();
            $data_order['date_created'] = $order->order_date;
        }
        if ($data_order) {
            $id_cart++;
            $id_customer = (int)ets_oneclicktomigrate_get_id_customer($ids_customer, (isset($data_order['customer_id']) && $data_order['customer_id'] ? $data_order['customer_id'] : $id . '-0'));
            if (method_exists($order, 'get_data') && isset($data_order['customer_note']) && $data_order['customer_note']) {
                $auto_increment++;
                $message = array(
                    'id_message' => $auto_increment,
                    'id_customer' => $id_customer,
                    'id_cart' => $id_cart,
                    'id_order' => $id,
                    'id_employee' => 0,
                    'message' => $data_order['customer_note'],
                    'private' => 0,
                    'date_add' => date_format(date_create((is_object($data_order['date_created']) ? $data_order['date_created']->__toString() : $data_order['date_created'])), 'Y-m-d h:i:s'),
                );
                $xml_output .= '<message>' . "\n";
                foreach ($message as $key => $value) {
                    $xml_output .= '<' . $key . '><![CDATA[' . $value . ']]></' . $key . '>' . "\n";
                }
                $xml_output .= '</message>' . "\n";
                ets_cache_tracking(++$item_export, $time);
            }
            if (!method_exists($order, 'get_data') && isset($data_order['customer_note']) && $data_order['customer_note']) {
                foreach ($data_order['customer_note'] as $note) {
                    $auto_increment++;
                    $message = array(
                        'id_message' => $auto_increment,
                        'id_customer' => $id_customer,
                        'id_cart' => $id_cart,
                        'id_order' => $id,
                        'id_employee' => 0,
                        'message' => $note->comment_content,
                        'private' => 0,
                        'date_add' => date_format(date_create((is_object($data_order['date_created']) ? $data_order['date_created']->__toString() : $data_order['date_created'])), 'Y-m-d h:i:s'),
                    );
                    $xml_output .= '<message>' . "\n";
                    foreach ($message as $key => $value) {
                        $xml_output .= '<' . $key . '><![CDATA[' . $value . ']]></' . $key . '>' . "\n";
                    }
                    $xml_output .= '</message>' . "\n";
                    ets_cache_tracking(++$item_export, $time);
                }
            }
            global $wpdb;
            if (($results = $wpdb->get_results("SELECT * FROM " . $wpdb->prefix . "comments WHERE  `comment_post_ID` = " . (int)$id . " AND  `comment_type` LIKE  'order_note'"))) {
                foreach ($results as $result) {
                    $auto_increment++;
                    $message = array(
                        'id_message' => $auto_increment,
                        'id_customer' => $id_customer,
                        'id_cart' => $id_cart,
                        'id_order' => $id,
                        'id_employee' => 1,
                        'message' => $result->comment_content,
                        'private' => 0,
                        'date_add' => $result->comment_date,
                    );
                    $xml_output .= '<message>' . "\n";
                    foreach ($message as $key => $value) {
                        $xml_output .= '<' . $key . '><![CDATA[' . $value . ']]></' . $key . '>' . "\n";
                    }
                    $xml_output .= '</message>' . "\n";
                    ets_cache_tracking(++$item_export, $time);
                }
            }
        }
    }
    $xml_output .= '</entity_profile>' . "\n";
    ets_cache_tracking($item_export);
    ets_cache_exports(array('total_order_message' => $auto_increment, 'cached_id_cart' => $id_cart, 'om_paged' => ($paged < 0 ? 0 : $paged)));
    if ($auto_increment <= $ikCached)
        return false;
    return $xml_output;
}

function ets_oneclicktomigrate_export_currencies()
{
    $item_export = ets_get_cache_tracking();
    ets_cache_export('export_table', 'currency');
    $time = time();
    $xml_output = '<?xml version="1.0" encoding="UTF-8"?>' . "\n";
    $xml_output .= '<entity_profile>' . "\n";
    $auto_increment = 0;
    if (($currencies = get_woocommerce_currencies())) {
        foreach ($currencies as $iso_code => $currency) {
            $auto_increment++;
            $currency_symbol = get_woocommerce_currency_symbol($iso_code);//html_entity_decode()
            $xml_output .= '<currency>' . "\n";
            $xml_output .= '<id_currency><![CDATA[' . $auto_increment . ']]></id_currency>' . "\n";
            $xml_output .= '<name><![CDATA[' . $currency . ']]></name>' . "\n";//html_entity_decode()
            $xml_output .= '<iso_code><![CDATA[' . $iso_code . ']]></iso_code>' . "\n";
            $xml_output .= '<sign><![CDATA[' . $currency_symbol . ']]></sign>' . "\n";
            $xml_output .= '<blank><![CDATA[1]]></blank>' . "\n";
            $xml_output .= '<format><![CDATA[1]]></format>' . "\n";
            $xml_output .= '<decimals><![CDATA[1]]></decimals>' . "\n";
            $xml_output .= '<conversion_rate><![CDATA[1]]></conversion_rate>' . "\n";
            $xml_output .= '<deleted><![CDATA[0]]></deleted>' . "\n";
            $xml_output .= '<active><![CDATA[' . (get_option('woocommerce_currency') == $iso_code ? 1 : 0) . ']]></active>' . "\n";
            $xml_output .= '</currency>' . "\n";
            ets_cache_tracking(++$item_export, $time);
        }
    }
    $xml_output .= '</entity_profile>' . "\n";
    ets_cache_tracking($item_export);
    ets_cache_export('total_currency', $auto_increment);
    if (!$auto_increment)
        return false;
    return $xml_output;
}

function ets_oneclicktomigrate_get_id_currency($iso_code)
{
    $currencies = get_woocommerce_currencies();
    $id_currency = 1;
    if ($currencies) {
        foreach ($currencies as $key => $currency) {
            if ($iso_code == $key)
                return $id_currency;
            $id_currency++;
        }
    }
    return 0;
}

function ets_oneclicktomigrate_export_order_status()
{
    $item_export = ets_get_cache_tracking();
    ets_cache_export('export_table', 'status');
    $time = time();
    $xml_output = '<?xml version="1.0" encoding="UTF-8"?>' . "\n";
    $xml_output .= '<entity_profile>' . "\n";
    $auto_increment = 14;
    if (($statuses = wc_get_order_statuses())) {
        foreach ($statuses as $status) {
            $auto_increment++;
            $xml_output .= '<order_state>' . "\n";
            $xml_output .= '<id_order_state><![CDATA[' . $auto_increment . ']]></id_order_state>' . "\n";
            $xml_output .= '<invoice><![CDATA[0]]></invoice>' . "\n";
            $xml_output .= '<send_email><![CDATA[0]]></send_email>' . "\n";
            $xml_output .= '<color><![CDATA[lightblue]]></color>' . "\n";
            $xml_output .= '<unremovable><![CDATA[0]]></unremovable>' . "\n";
            $xml_output .= '<hidden><![CDATA[0]]></hidden>' . "\n";
            $xml_output .= '<logable><![CDATA[0]]></logable>' . "\n";
            $xml_output .= '<delivery><![CDATA[0]]></delivery>' . "\n";
            $xml_output .= '<deleted><![CDATA[0]]></deleted>' . "\n";
            $xml_output .= '<datalanguage>' . "\n";
            $xml_output .= '<name><![CDATA[' . $status . ']]></name>' . "\n";
            $xml_output .= '<template><![CDATA[cheque]]></template>' . "\n";
            $xml_output .= '</datalanguage>' . "\n";
            $xml_output .= '</order_state>' . "\n";
            ets_cache_tracking(++$item_export, $time);
        }
    }
    $xml_output .= '</entity_profile>' . "\n";
    ets_cache_tracking($item_export);
    ets_cache_export('total_order_status', $auto_increment);
    if ($auto_increment <= 14)
        return false;
    return $xml_output;
}

function ets_oneclicktomigrate_get_id_status($name)
{
    $statuses = wc_get_order_statuses();
    $id_state = 15;
    foreach ($statuses as $key => $status) {
        if ('wc-' . $name == $key) {
            return $id_state;
        }
        $id_state++;
    }
    return 0;
}

function ets_oneclicktomigrate_get_id_state($iso_code_state, $iso_code_country)
{
    $countries = new WC_Countries();
    $id_state = 15;
    if (($countries = $countries->get_states())) {
        foreach ($countries as $iso_country => $states) {
            if ($states) {
                foreach ($states as $iso_state => $state) {
                    if ($iso_code_state == $iso_state && $iso_code_country == $iso_country)
                        return $id_state;
                    $id_state++;
                }
            }
        }
    }
    return 0;
}

function ets_oneclicktomigrate_is_iso_code($iso_code)
{
    if (!preg_match('/^[a-zA-Z0-9]{1,4}((-)[a-zA-Z0-9]{1,4})?$/', $iso_code)) {
        return 'ISO-CODE';
    }
    return $iso_code;
}

function ets_oneclicktomigrate_export_states()
{
    $item_export = ets_get_cache_tracking();
    ets_cache_export('export_table', 'state');
    $time = time();
    $countries = new WC_Countries();
    $auto_increment = 14;
    $xml_output = '<?xml version="1.0" encoding="UTF-8"?>' . "\n";
    $xml_output .= '<entity_profile>' . "\n";
    if (($countries = $countries->get_states())) {
        foreach ($countries as $iso_code_country => $states) {
            if ($states) {
                foreach ($states as $iso_state => $state) {
                    $auto_increment++;
                    $xml_output .= '<state>' . "\n";
                    $xml_output .= '<id_state><![CDATA[' . $auto_increment . ']]></id_state>' . "\n";
                    $xml_output .= '<id_country><![CDATA[' . ets_oneclicktomigrate_get_id_country($iso_code_country) . ']]></id_country>' . "\n";
                    $xml_output .= '<id_zone><![CDATA[0]]></id_zone>' . "\n";
                    $xml_output .= '<name><![CDATA[' . $state . ']]></name>' . "\n";
                    $xml_output .= '<iso_code><![CDATA[' . ets_oneclicktomigrate_is_iso_code($iso_state) . ']]></iso_code>' . "\n";
                    $xml_output .= '<tax_behavior><![CDATA[0]]></tax_behavior>' . "\n";
                    $xml_output .= '<active><![CDATA[1]]></active>' . "\n";
                    $xml_output .= '</state>' . "\n";
                    ets_cache_tracking(++$item_export, $time);
                }
            }
        }
    }
    $xml_output .= '</entity_profile>' . "\n";
    ets_cache_tracking($item_export);
    ets_cache_export('total_state', $auto_increment - 14);
    if ($auto_increment <= 14)
        return false;
    return $xml_output;
}

function ets_oneclicktomigrate_export_specific_price($args = array())
{
    $paged = -1;
    if (isset($args['paged']))
        $paged = (int)$args['paged'];
    $products = ets_get_cache_product($paged);
    if (!$products)
        $products = ets_oneclicktomigrate_get_products($args);
    if (!$products) {
        ets_cache_export('specific_price', 1);
        ets_return_json(array('export' => 'SpecificPrice-end.xml'));
    }
    $item_export = ets_get_cache_tracking();
    ets_cache_export('export_table', 'specific_price');
    $time = time();

    $auto_increment = ($ikCached = (int)ets_get_cache_export('total_specific_price')) ? $ikCached : 0;
    $xml_output = '<?xml version="1.0" encoding="UTF-8"?>' . "\n";
    $xml_output .= '<entity_profile>' . "\n";
    foreach ($products as $product) {
        $product = ets_oneclicktomigrate_get_product_data($product);
        if ($product && $product->sale_price && $product->sale_price < $product->regular_price) {
            $auto_increment++;
            $xml_output .= '<specific_price>' . "\n";
            $xml_output .= '<id_specific_price><![CDATA[' . $auto_increment . ']]></id_specific_price>' . "\n";
            $xml_output .= '<id_shop_group><![CDATA[0]]></id_shop_group>' . "\n";
            $xml_output .= '<id_shop><![CDATA[0]]></id_shop>' . "\n";
            $xml_output .= '<id_cart><![CDATA[0]]></id_cart>' . "\n";
            $xml_output .= '<id_product><![CDATA[' . $product->ID . ']]></id_product>' . "\n";
            $xml_output .= '<id_currency><![CDATA[0]]></id_currency>' . "\n";
            $xml_output .= '<id_product_attribute><![CDATA[0]]></id_product_attribute>' . "\n";
            $xml_output .= '<id_specific_price_rule><![CDATA[0]]></id_specific_price_rule>' . "\n";
            $xml_output .= '<id_country><![CDATA[0]]></id_country>' . "\n";
            $xml_output .= '<id_group><![CDATA[0]]></id_group>' . "\n";
            $xml_output .= '<id_customer><![CDATA[0]]></id_customer>' . "\n";
            $xml_output .= '<price><![CDATA[-1.000000]]></price>' . "\n";
            $xml_output .= '<from_quantity><![CDATA[1]]></from_quantity>' . "\n";
            $xml_output .= '<reduction><![CDATA[' . ($product->regular_price - $product->sale_price) . ']]></reduction>' . "\n";
            $xml_output .= '<reduction_tax><![CDATA[0]]></reduction_tax>' . "\n";
            $xml_output .= '<reduction_type><![CDATA[amount]]></reduction_type>' . "\n";
            $xml_output .= '<from><![CDATA[' . ($product->sale_price_dates_from ? $product->sale_price_dates_from : '0000-00-00 00:00:00') . ']]></from>' . "\n";
            $xml_output .= '<to><![CDATA[' . ($product->sale_price_dates_to ? $product->sale_price_dates_to : '0000-00-00 00:00:00') . ']]></to>' . "\n";
            $xml_output .= '</specific_price>' . "\n";
            ets_cache_tracking(++$item_export, $time);
        }
    }
    $xml_output .= '</entity_profile>' . "\n";
    ets_cache_tracking($item_export);
    ets_cache_exports(array('total_specific_price' => $auto_increment, 'specific_paged' => ($paged < 0 ? 0 : $paged)));
    if ($auto_increment <= $ikCached)
        return false;
    return $xml_output;
}

function ets_oneclicktomigrate_export_accessory_product($args)
{
    $paged = -1;
    if (isset($args['paged']))
        $paged = (int)$args['paged'];
    $products = ets_get_cache_product($paged);
    if (!$products)
        $products = ets_oneclicktomigrate_get_products($args);
    if (!$products) {
        ets_cache_export('accessory', 1);
        ets_return_json(array('export' => 'accessory-end.xml'));
    }
    $auto_increment = ($ikCached = (int)ets_get_cache_export('total_accessory')) ? $ikCached : 0;

    $item_export = ets_get_cache_tracking();
    ets_cache_export('export_table', 'accessory_product');
    $time = time();

    $xml_output = '<?xml version="1.0" encoding="UTF-8"?>' . "\n";
    $xml_output .= '<entity_profile>' . "\n";
    foreach ($products as $id_product) {
        $product = new WC_Product($id_product);
        if (method_exists($product, 'get_upsell_ids'))
            $up_sells = $product->get_upsell_ids();
        else
            $up_sells = $product->get_upsells();
        if ($up_sells) {
            foreach ($up_sells as $up_sell) {
                $auto_increment++;
                $xml_output .= '<accessory>' . "\n";
                $xml_output .= '<id_product_1><![CDATA[' . (int)$id_product . ']]></id_product_1>' . "\n";
                $xml_output .= '<id_product_2><![CDATA[' . (int)$up_sell . ']]></id_product_2>' . "\n";
                $xml_output .= '</accessory>' . "\n";
                ets_cache_tracking(++$item_export, $time);
            }
        }
        if (method_exists($product, 'get_cross_sell_ids'))
            $cross_sells = $product->get_cross_sell_ids();
        else
            $cross_sells = $product->get_cross_sells();
        if ($cross_sells) {
            foreach ($cross_sells as $cross_sell) {
                $auto_increment++;
                $xml_output .= '<accessory>' . "\n";
                $xml_output .= '<id_product_1><![CDATA[' . (int)$id_product . ']]></id_product_1>' . "\n";
                $xml_output .= '<id_product_2><![CDATA[' . (int)$cross_sell . ']]></id_product_2>' . "\n";
                $xml_output .= '</accessory>' . "\n";
                ets_cache_tracking(++$item_export, $time);
            }
        }
    }
    $xml_output .= '</entity_profile>' . "\n";
    ets_cache_tracking($item_export);
    ets_cache_exports(array('total_accessory' => $auto_increment, 'accessory_paged' => ($paged < 0 ? 0 : $paged)));
    if ($auto_increment <= $ikCached)
        return false;
    return $xml_output;
}

function ets_oneclicktomigrate_export_tax_rule_group()
{
    $item_export = ets_get_cache_tracking();
    ets_cache_export('export_table', 'tax_rule_group');
    $time = time();
    $taxs = WC_Tax::get_tax_classes();
    $tax_groups = array();
    $auto_increment = 1;
    $xml_output = '<?xml version="1.0" encoding="UTF-8"?>' . "\n";
    $xml_output .= '<entity_profile>' . "\n";
    $xml_output .= '<tax_rules_group>' . "\n";
    $xml_output .= '<id_tax_rules_group><![CDATA[1]]></id_tax_rules_group>' . "\n";
    $xml_output .= '<name><![CDATA[Standard]]></name>' . "\n";
    $xml_output .= '<active><![CDATA[1]]></active>' . "\n";
    $xml_output .= '<deleted><![CDATA[0]]></deleted>' . "\n";
    $xml_output .= '<date_add><![CDATA[' . date('Y-m-d h:i:s', time()) . ']]></date_add>' . "\n";
    $xml_output .= '<date_upd><![CDATA[' . date('Y-m-d h:i:s', time()) . ']]></date_upd>' . "\n";
    $xml_output .= '</tax_rules_group>' . "\n";
    ets_cache_tracking(++$item_export);
    if ($taxs) {
        foreach ($taxs as $tax) {
            if (!in_array($tax, $tax_groups)) {
                $auto_increment++;
                $tax_groups[] = $tax;
                $xml_output .= '<tax_rules_group>' . "\n";
                $xml_output .= '<id_tax_rules_group><![CDATA[' . $auto_increment . ']]></id_tax_rules_group>' . "\n";
                $xml_output .= '<name><![CDATA[' . $tax . ']]></name>' . "\n";
                $xml_output .= '<active><![CDATA[1]]></active>' . "\n";
                $xml_output .= '<deleted><![CDATA[0]]></deleted>' . "\n";
                $xml_output .= '<date_add><![CDATA[' . date('Y-m-d h:i:s', time()) . ']]></date_add>' . "\n";
                $xml_output .= '<date_upd><![CDATA[' . date('Y-m-d h:i:s', time()) . ']]></date_upd>' . "\n";
                $xml_output .= '</tax_rules_group>' . "\n";
                ets_cache_tracking(++$item_export, $time);
            }
        }
    }
    $xml_output .= '</entity_profile>' . "\n";
    ets_cache_tracking($item_export);
    ets_cache_export('total_tax_rule_group', $auto_increment);
    return $xml_output;
}

function ets_oneclicktomigrate_get_id_tax_rule_group($name = null)
{
    if (!$name)
        return 1;
    $taxs = WC_Tax::get_tax_classes();
    $tax_groups = array();
    $id_tax_group = 2;
    if ($taxs) {
        foreach ($taxs as $tax) {
            if ($tax == $name) {
                return $id_tax_group;
            }
            if (!in_array($tax, $tax_groups)) {
                $tax_groups[] = $tax;
                $id_tax_group++;
            }
        }
    }
    return 0;
}

function ets_oneclicktomigrate_export_tax()
{
    $item_export = ets_get_cache_tracking();
    ets_cache_export('export_table', 'tax');
    $time = time();
    global $wpdb;
    $tax_rates = $wpdb->get_results("
        SELECT *
        FROM {$wpdb->prefix}woocommerce_tax_rates AS tr
        GROUP BY tax_rate,tax_rate_name
    ");
    $auto_increment = 0;
    $xml_output = '<?xml version="1.0" encoding="UTF-8"?>' . "\n";
    $xml_output .= '<entity_profile>' . "\n";
    if ($tax_rates) {
        foreach ($tax_rates as $tax) {
            $auto_increment++;
            $xml_output .= '<tax>' . "\n";
            $xml_output .= '<id_tax><![CDATA[' . (int)$auto_increment . ']]></id_tax>' . "\n";
            $xml_output .= '<rate><![CDATA[' . $tax->tax_rate . ']]></rate>' . "\n";
            $xml_output .= '<active><![CDATA[1]]></active>' . "\n";
            $xml_output .= '<deleted><![CDATA[0]]></deleted>' . "\n";
            $xml_output .= '<datalanguage>' . "\n";
            $xml_output .= '<name><![CDATA[' . $tax->tax_rate_name . ']]></name>' . "\n";
            $xml_output .= '</datalanguage>' . "\n";
            $xml_output .= '</tax>' . "\n";
            ets_cache_tracking(++$item_export, $time);
        }
    }
    $xml_output .= '</entity_profile>' . "\n";
    ets_cache_tracking($item_export);
    ets_cache_export('total_tax', $auto_increment);
    if (!$auto_increment)
        return false;
    return $xml_output;
}

function ets_oneclicktomigrate_get_id_tax($tax_rate, $tax_rate_name)
{
    global $wpdb;
    $taxs = $wpdb->get_results("SELECT * FROM {$wpdb->prefix}woocommerce_tax_rates AS tr GROUP BY tax_rate,tax_rate_name");
    $id_tax = 1;
    if ($taxs) {
        foreach ($taxs as $tax) {
            if ($tax->tax_rate == $tax_rate && $tax->tax_rate_name == $tax_rate_name)
                return $id_tax;
            $id_tax++;
        }
    }
    return 0;
}

function ets_oneclicktomigrate_export_tax_rule()
{
    $item_export = ets_get_cache_tracking();
    ets_cache_export('export_table', 'tax_rule');
    $time = time();
    global $wpdb;
    $tax_rules = $wpdb->get_results("SELECT * FROM {$wpdb->prefix}woocommerce_tax_rates AS tr");
    $auto_increment = 0;
    $xml_output = '<?xml version="1.0" encoding="UTF-8"?>' . "\n";
    $xml_output .= '<entity_profile>' . "\n";
    if ($tax_rules) {
        foreach ($tax_rules as $tax_rule) {
            if ($tax_rule->tax_rate_country && $id_country = ets_oneclicktomigrate_get_id_country($tax_rule->tax_rate_country)) {
                $auto_increment++;
                $xml_output .= '<tax_rule>' . "\n";
                $xml_output .= '<id_tax_rule><![CDATA[' . $auto_increment . ']]></id_tax_rule>' . "\n";
                $xml_output .= '<id_tax_rules_group><![CDATA[' . (int)ets_oneclicktomigrate_get_id_tax_rule_group($tax_rule->tax_rate_class) . ']]></id_tax_rules_group>' . "\n";
                $xml_output .= '<id_country><![CDATA[' . (int)$id_country . ']]></id_country>' . "\n";
                $xml_output .= '<id_state><![CDATA[' . (int)ets_oneclicktomigrate_get_id_state($tax_rule->tax_rate_state, $tax_rule->tax_rate_country) . ']]></id_state>' . "\n";
                $xml_output .= '<zipcode_from><![CDATA[]]></zipcode_from>' . "\n";
                $xml_output .= '<zipcode_to><![CDATA[]]></zipcode_to>' . "\n";
                $xml_output .= '<id_tax><![CDATA[' . ets_oneclicktomigrate_get_id_tax($tax_rule->tax_rate, $tax_rule->tax_rate_name) . ']]></id_tax>' . "\n";
                $xml_output .= '<behavior><![CDATA[1]]></behavior>' . "\n";
                $xml_output .= '<description><![CDATA[]]></description>' . "\n";
                $xml_output .= '</tax_rule>' . "\n";
                ets_cache_tracking(++$item_export, $time);
            } else {
                $countries = new WC_Countries();
                $countries = $countries->get_countries();
                if ($countries) {
                    $id_country = 0;
                    foreach ($countries as $key => $country) {
                        $auto_increment++;
                        $id_country++;
                        $xml_output .= '<tax_rule>' . "\n";
                        $xml_output .= '<id_tax_rule><![CDATA[' . $auto_increment . ']]></id_tax_rule>' . "\n";
                        $xml_output .= '<id_tax_rules_group><![CDATA[' . (int)ets_oneclicktomigrate_get_id_tax_rule_group($tax_rule->tax_rate_class) . ']]></id_tax_rules_group>' . "\n";
                        $xml_output .= '<id_country><![CDATA[' . (int)$id_country . ']]></id_country>' . "\n";
                        $xml_output .= '<id_state><![CDATA[' . (int)ets_oneclicktomigrate_get_id_state($tax_rule->tax_rate_state, $key) . ']]></id_state>' . "\n";
                        $xml_output .= '<zipcode_from><![CDATA[]]></zipcode_from>' . "\n";
                        $xml_output .= '<zipcode_to><![CDATA[]]></zipcode_to>' . "\n";
                        $xml_output .= '<id_tax><![CDATA[' . ets_oneclicktomigrate_get_id_tax($tax_rule->tax_rate, $tax_rule->tax_rate_name) . ']]></id_tax>' . "\n";
                        $xml_output .= '<behavior><![CDATA[1]]></behavior>' . "\n";
                        $xml_output .= '<description><![CDATA[]]></description>' . "\n";
                        $xml_output .= '</tax_rule>' . "\n";
                        ets_cache_tracking(++$item_export, $time);
                    }
                }
            }
        }
    }
    $xml_output .= '</entity_profile>' . "\n";
    ets_cache_tracking($item_export);
    ets_cache_export('total_tax_rule', $auto_increment);
    if (!$auto_increment)
        return false;
    return $xml_output;
}

function ets_oneclicktomigrate_export_cart_rule()
{
    $item_export = ets_get_cache_tracking();
    ets_cache_export('export_table', 'cart_rule');
    $time = time();
    $args = array(
        'posts_per_page' => -1,
        'orderby' => 'title',
        'order' => 'asc',
        'post_type' => 'shop_coupon',
        'post_status' => 'publish',
    );
    $xml_output = '<?xml version="1.0" encoding="UTF-8"?>' . "\n";
    $xml_output .= '<entity_profile>' . "\n";
    $count = 0;
    if (($coupons = get_posts($args))) {
        foreach ($coupons as $coupon) {
            $id_coupon = $coupon->ID;
            $wc_coupon = new WC_Coupon($coupon->post_name);
            if (method_exists($wc_coupon, 'get_data'))
                $data_coupon = $wc_coupon->get_data();
            else
                $data_coupon = (array)$wc_coupon;
            $xml_output .= '<cart_rule>' . "\n";
            $xml_output .= '<id_cart_rule><![CDATA[' . (int)$id_coupon . ']]></id_cart_rule>' . "\n";
            $xml_output .= '<id_customer><![CDATA[0]]></id_customer>' . "\n";
            $now = $data_coupon['date_expires'] ? date(date_format(date_create($data_coupon['date_expires']->__toString()), 'Y-m-d h:i:s')) : date("Y-m-d h:i:s");
            $xml_output .= '<date_from><![CDATA[' . $now . ']]></date_from>' . "\n";
            $date_minus = date("Y-m-d H:i:s", strtotime("$now +1 year"));
            $xml_output .= '<date_to><![CDATA[' . $date_minus . ']]></date_to>' . "\n";
            $xml_output .= '<description><![CDATA[]]></description>' . "\n";
            $xml_output .= '<quantity><![CDATA[9999]]></quantity>' . "\n";
            $xml_output .= '<quantity_per_user><![CDATA[9999]]></quantity_per_user>' . "\n";
            $xml_output .= '<priority><![CDATA[' . $id_coupon . ']]></priority>' . "\n";
            $xml_output .= '<partial_use><![CDATA[1]]></partial_use>' . "\n";
            $xml_output .= '<code><![CDATA[' . $data_coupon['code'] . ']]></code>' . "\n";
            $xml_output .= '<minimum_amount><![CDATA[' . $data_coupon['minimum_amount'] . ']]></minimum_amount>' . "\n";
            $xml_output .= '<minimum_amount_tax><![CDATA[' . $data_coupon['minimum_amount'] . ']]></minimum_amount_tax>' . "\n";
            $xml_output .= '<minimum_amount_currency><![CDATA[' . ets_oneclicktomigrate_get_id_currency(get_option('woocommerce_currency')) . ']]></minimum_amount_currency>' . "\n";
            $xml_output .= '<minimum_amount_shipping><![CDATA[0]]></minimum_amount_shipping>' . "\n";
            $xml_output .= '<country_restriction><![CDATA[0]]></country_restriction>' . "\n";
            $xml_output .= '<carrier_restriction><![CDATA[0]]></carrier_restriction>' . "\n";
            $xml_output .= '<group_restriction><![CDATA[0]]></group_restriction>' . "\n";
            $xml_output .= '<cart_rule_restriction><![CDATA[0]]></cart_rule_restriction>' . "\n";
            $xml_output .= '<product_restriction><![CDATA[0]]></product_restriction>' . "\n";
            $xml_output .= '<shop_restriction><![CDATA[0]]></shop_restriction>' . "\n";
            $xml_output .= '<free_shipping><![CDATA[' . $data_coupon['free_shipping'] . ']]></free_shipping>' . "\n";
            $xml_output .= '<reduction_percent><![CDATA[' . ($data_coupon['discount_type'] == 'percent' ? $data_coupon['amount'] : 0) . ']]></reduction_percent>' . "\n";
            $xml_output .= '<reduction_amount><![CDATA[' . ($data_coupon['discount_type'] != 'percent' ? $data_coupon['amount'] : 0) . ']]></reduction_amount>' . "\n";
            $xml_output .= '<reduction_tax><![CDATA[0]]></reduction_tax>' . "\n";
            $xml_output .= '<reduction_currency><![CDATA[' . ets_oneclicktomigrate_get_id_currency(get_option('woocommerce_currency')) . ']]></reduction_currency>' . "\n";
            $xml_output .= '<reduction_product><![CDATA[' . ($data_coupon['discount_type'] == 'fixed_product' ? 1 : 0) . ']]></reduction_product>' . "\n";
            $xml_output .= '<gift_product><![CDATA[0]]></gift_product>' . "\n";
            $xml_output .= '<gift_product_attribute><![CDATA[0]]></gift_product_attribute>' . "\n";
            $xml_output .= '<highlight><![CDATA[0]]></highlight>' . "\n";
            $xml_output .= '<active><![CDATA[1]]></active>' . "\n";
            $xml_output .= '<date_add><![CDATA[' . $coupon->post_date . ']]></date_add>' . "\n";
            $xml_output .= '<date_upd><![CDATA[' . $coupon->post_date_gmt . ']]></date_upd>' . "\n";
            $xml_output .= '<datalanguage>' . "\n";
            $xml_output .= '<name><![CDATA[' . $coupon->post_title . ']]></name>' . "\n";
            $xml_output .= '</datalanguage>' . "\n";
            $xml_output .= '</cart_rule>' . "\n";
            $count++;
            ets_cache_tracking(++$item_export, $time);
        }
    }
    $xml_output .= '</entity_profile>' . "\n";
    ets_cache_tracking($item_export);
    ets_cache_export('total_cart_rule', $count);
    if (!$count)
        return false;
    return $xml_output;
}
