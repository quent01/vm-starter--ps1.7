<div class="wrap woocommerce">
    <form id="module_form" action="<?php echo admin_url('admin.php?page=export_data', (is_ssl()? 'https': 'http')) ?>" novalidate="" enctype="multipart/form-data" method="post" >
        <h2><?php  echo __('Woo2Pres','woo2presconnector'); ?></h2>
        <?php if(isset($ok_save) && $ok_save) { ?>
            <div id="message" class="updated inline">
                <p>
                    <strong><?php echo __('Your settings have been saved.','woo2presconnector'); ?></strong>
                </p>
            </div>
        <?php } elseif (isset($errors) && $errors) {?>
            <div id="ets_oneclicktomigrate_errors" class="inline">
                <ul>
                    <?php foreach ($errors as $error) { ?>
                    <li>
                        <span><?php echo $error; ?></span>
                    </li>
                    <?php }  ?>
                </ul>
            </div>
        <?php }?>
        <p><?php echo __('Feed Woocommerce data, Wordpress posts and pages for Woocommerce (Wordpress) to Prestashop migration!','woo2presconnector'); ?></p>
        <h3><?php echo __('Direct migration','woo2presconnector'); ?></h3>
        <table class="form-table">
            <tbody>
            <tr valign="top">
                <th class="titledesc" scope="row">
                    <label for="ets_woo2presconnector_enabled"><?php echo __('Enable/Disable','woo2presconnector'); ?></label>
                </th>
                <td class="forminp">
                    <fieldset>
                        <legend class="screen-reader-text">
                            <span><?php echo __('Enable/Disable','woo2presconnector'); ?></span>
                        </legend>
                        <label for="ets_woo2presconnector_enabled">
                            <input id="" class="" type="checkbox"  <?php if(get_option('ets_woo2presconnector_enabled')){?> checked="checked" <?php }?> value="1" style="" name="ets_woo2presconnector_enabled" />
                            <?php echo __('Enable Direct migration','woo2presconnector'); ?>
                        </label>
                        <br />
                    </fieldset>
                </td>
            </tr>
            <tr valign="top">
                <th class="titledesc" scope="row">
                    <span class="woocommerce-help-tip"></span>
                    <label for="ets_oneclicktomigrate_tocken"><?php echo __('Secure access token','woo2presconnector'); ?></label>
                </th>
                <td class="forminp">
                    <fieldset>
                        <legend class="screen-reader-text">
                            <span><?php echo __('Secure access token','woo2presconnector'); ?></span>
                        </legend>
                        <input style="float: left; width: 200px;" type="text" placeholder="" value="<?php echo get_option('ets_oneclicktomigrate_tocken'); ?>" style="" id="ets_oneclicktomigrate_tocken" name="ets_oneclicktomigrate_tocken" class="input-text regular-input " />
                        <span class="input-group-btn" style="float: left; margin-top: 3px;">
                                <a class="btn btn-default button-primary" href="javascript:gencode(6);">Generate</a>
                            </span>
                    </fieldset>
                </td>
            </tr>
            <tr valign="top">
                <th class="titledesc" scope="row">
                    <span class="woocommerce-help-tip"></span>
                    <label for="ets_oneclicktomigrate_tocken"><?php echo __('Database records exported per ajax request','woo2presconnector'); ?></label>
                </th>
                <td class="forminp">
                    <fieldset>
                        <legend class="screen-reader-text">
                            <span><?php echo __('Database records exported per Ajax request','woo2presconnector'); ?></span>
                        </legend>
                        <input style="float: left; width: 200px;" type="text" placeholder="" value="<?php echo get_option('ets_woo2presconnector_records'); ?>" style="" id="ets_woo2presconnector_records" name="ets_woo2presconnector_records" class="input-text regular-input " />
                    </fieldset>
                </td>
            </tr >
            <tr valign="top">
                <td colspan="2">
					<span class="ets_woo2presconnector_desc">
						<?php echo __('Default value is 200. Decrease this value if your server is not good (low speed, limited server, etc...)','woo2presconnector'); ?>
					</span>
                </td>
            </tr>
            </tbody>
        </table>
        <p class="submit">
            <input name="submitExport" type="hidden" value="1"/>
            <button value="<?php echo __('Save changes','woo2presconnector'); ?>" type="submit" class="button-primary" name="save_woo2presconnector"><?php echo __('Save changes','woo2presconnector'); ?></button>
        </p><br /><br />
        <h3><?php echo __('Download entire data for migration','woo2presconnector'); ?></h3>
        <p><?php echo __('Besides direct migration using','woo2presconnector'); ?> <strong>"<?php echo __('Secure acccess token','woo2presconnector'); ?>"</strong>, <?php echo __('you can also download entire website data from Wordpress then importing the data into Prestashop using Woocommerce to Prestashop migration module','woo2presconnector'); ?></p>
        <p class="submit">
            <button value="<?php echo __('Save changes','woo2presconnector'); ?>" type="submit" class="button-primary" name="submitExport"><?php echo __('Dowload website data','woo2presconnector'); ?></button>
        </p>
    </form>
</div>
<script type="text/javascript">
    function gencode(size)
    {
        var code_value = '';
        /* There are no O/0 in the codes in order to avoid confusion */
        var chars = "123456789abcdefghijklmnpqrstuvwxyzABCDEFGHIJKLMNPQRSTUVWXYZ";
        for (var i = 1; i <= size; ++i)
            code_value += chars.charAt(Math.floor(Math.random() * chars.length));
        jQuery('#ets_oneclicktomigrate_tocken').val(code_value);
    }
    jQuery(document).on('click','#ets_oneclicktomigrate_tocken',function(){
        jQuery(this).select();
    });
</script>
