<?php
/*
Plugin Name: Woo2Pres Connector
Description: Feed Woocommerce data, Wordpress posts and pages for Woocommerce (Prestashop) to Prestashop migration!
Author: ETS-Soft
*/

add_filter( 'plugin_action_links_' . plugin_basename(__FILE__), 'add_action_links' );
add_action( 'activated_plugin', 'ets_oneclicktomigrate_set_default_value', plugin_basename(__FILE__));
function add_action_links ( $links ) {
    $mylinks = array(
        '<a href="' . admin_url('admin.php?page=export_data') . '">'.__("Settings","woo2presconnector").'</a>',
    );
    return array_merge( $links, $mylinks );
}
function ets_oneclicktomigrate_set_default_value($plugin)
{
    if($plugin=='woo2presconnector/woo2presconnector.php')
    {
        update_option('ets_oneclicktomigrate_tocken', ets_oneclicktomigrate_genSecure(6));
        update_option('ets_woo2presconnector_enabled', 1);
    }
}
//fix install plugin woocommerce.
if((isset($_GET['page']) && $_GET['page'] != 'wc-setup') || !(isset($_GET['page'])))
{
    require_once plugin_dir_path(__FILE__) . 'includes/ets_oneclicktomigrate-functions.php';
}