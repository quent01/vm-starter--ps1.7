jQuery(function ($) {
    var ets_func = {
        export : function(button) {
            if (ets_func.getCookie('zip_file_name') != '' && typeof ajax_object.ajax_url !== "undefined")
            {
                var submitForm = button.parents('form');
                var formData = new FormData(submitForm.get(0));
                button.addClass('active');
                $.ajax({
                    url: ajax_object.ajax_url + '?action=ets_ajax_export&ajax=1&zip_file_name='+ets_func.getCookie('zip_file_name'),
                    data: formData,
                    type: 'post',
                    dataType: 'json',
                    processData: false,
                    contentType: false,
                    success: function(json) {
                        if (!json)
                            ets_func.export(button);
                        if (!json.errors && json.link_site_connector)
                        {
                            ets_func.setCookie('zip_file_name', '');
                            button.removeClass('active');
                            button.after('<a class="ets_download_file_zip" href="'+json.link_site_connector+'">'+json.link_site_connector+'</a>');
                        }
                        else
                            ets_func.export(button);
                    },
                    error: function(xhr, status, error)
                    {
                        ets_func.export(button);
                    }
                });
            }
        },
        genCode : function(size) {
            var code_value = '';
            var chars = "123456789abcdefghijklmnpqrstuvwxyzABCDEFGHIJKLMNPQRSTUVWXYZ";
            for (var i = 1; i <= size; ++i)
                code_value += chars.charAt(Math.floor(Math.random() * chars.length));
            return code_value;
        },
        setCookie : function (cname, cvalue) {
            var d = new Date();
            d.setTime(d.getTime() + (24*60*60*1000));
            var expires = "expires="+ d.toUTCString();
            document.cookie = cname + "=" + cvalue + ";" + expires + ";path=/";
        },
        getCookie: function (cname) {
            var name = cname + "=";
            var decodedCookie = decodeURIComponent(document.cookie);
            var ca = decodedCookie.split(';');
            for(var i = 0; i <ca.length; i++) {
                var c = ca[i];
                while (c.charAt(0) == ' ') {
                    c = c.substring(1);
                }
                if (c.indexOf(name) == 0) {
                    return c.substring(name.length, c.length);
                }
            }
            return '';
        }
    };

    $(document).on('click','button[name="submitExport"]', function(evt) {
        evt.preventDefault();
        $('.ets_download_file_zip').remove();
        ets_func.setCookie('zip_file_name', 'oc2m_data_' + ets_func.genCode(7));
        ets_func.export($(this));
    });
});