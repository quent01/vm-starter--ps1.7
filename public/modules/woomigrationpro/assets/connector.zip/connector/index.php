<?php
/*
Plugin Name: WooMigrationProConnector
Plugin URI: https://migration-pro.com/addons-demo/backoffice
Description: The WordPress Connector Module For the WooMigrationPro module
Version: 2.0.0
Author: MigrationProTeam
Author URI: https://migration-pro.com/addons-demo/backoffice
License: GPLv2 or later
Text Domain: https://migration-pro.com/addons-demo/backoffice
*/


